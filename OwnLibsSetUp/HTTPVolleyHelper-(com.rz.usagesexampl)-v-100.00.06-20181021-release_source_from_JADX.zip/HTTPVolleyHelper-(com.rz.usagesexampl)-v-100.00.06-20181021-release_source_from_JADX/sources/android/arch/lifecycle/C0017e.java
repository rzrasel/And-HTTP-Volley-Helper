package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.e */
public interface C0017e {
    /* renamed from: a */
    C0015c mo42a();
}
