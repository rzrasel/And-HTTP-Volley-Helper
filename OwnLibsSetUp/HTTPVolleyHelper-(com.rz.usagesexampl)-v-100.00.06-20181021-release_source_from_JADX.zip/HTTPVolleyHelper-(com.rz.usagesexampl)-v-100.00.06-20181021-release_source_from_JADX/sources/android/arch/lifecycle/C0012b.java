package android.arch.lifecycle;

import android.arch.lifecycle.C0015c.C0013a;

/* renamed from: android.arch.lifecycle.b */
public interface C0012b {
    /* renamed from: a */
    void m37a(C0017e c0017e, C0013a c0013a, boolean z, C0021i c0021i);
}
