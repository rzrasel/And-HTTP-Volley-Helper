package android.arch.lifecycle;

import java.util.HashMap;

/* renamed from: android.arch.lifecycle.p */
public class C0029p {
    /* renamed from: a */
    private final HashMap<String, C0026n> f41a = new HashMap();

    /* renamed from: a */
    public final void m62a() {
        for (C0026n a : this.f41a.values()) {
            a.mo35a();
        }
        this.f41a.clear();
    }
}
