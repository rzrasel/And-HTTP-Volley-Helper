package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.k */
public interface C0022k<T> {
    /* renamed from: a */
    void mo36a(T t);
}
