package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.j */
public class C0509j<T> extends LiveData<T> {
}
