package android.arch.lifecycle;

import android.arch.lifecycle.C0015c.C0013a;

public class SingleGeneratedAdapterObserver implements GenericLifecycleObserver {
    /* renamed from: a */
    private final C0012b f2596a;

    SingleGeneratedAdapterObserver(C0012b c0012b) {
        this.f2596a = c0012b;
    }

    /* renamed from: a */
    public void mo420a(C0017e c0017e, C0013a c0013a) {
        this.f2596a.m37a(c0017e, c0013a, false, null);
        this.f2596a.m37a(c0017e, c0013a, true, null);
    }
}
