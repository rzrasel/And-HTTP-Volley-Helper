package android.arch.lifecycle;

@Deprecated
/* renamed from: android.arch.lifecycle.g */
public interface C0508g extends C0017e {
    /* renamed from: b */
    C0507f m1994b();
}
