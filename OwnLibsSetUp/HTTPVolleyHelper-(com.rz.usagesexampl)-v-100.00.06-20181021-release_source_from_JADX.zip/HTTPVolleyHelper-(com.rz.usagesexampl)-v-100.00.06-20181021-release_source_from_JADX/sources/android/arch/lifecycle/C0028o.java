package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.o */
public class C0028o {

    /* renamed from: android.arch.lifecycle.o$a */
    public interface C0027a {
    }
}
