package android.arch.lifecycle;

interface FullLifecycleObserver extends C0016d {
    /* renamed from: a */
    void m1970a(C0017e c0017e);

    /* renamed from: b */
    void m1971b(C0017e c0017e);

    /* renamed from: c */
    void m1972c(C0017e c0017e);

    /* renamed from: d */
    void m1973d(C0017e c0017e);

    /* renamed from: e */
    void m1974e(C0017e c0017e);

    /* renamed from: f */
    void m1975f(C0017e c0017e);
}
