package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.n */
public abstract class C0026n {
    /* renamed from: a */
    protected void mo35a() {
    }
}
