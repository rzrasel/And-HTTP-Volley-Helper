package android.arch.lifecycle;

import java.util.HashMap;
import java.util.Map;

/* renamed from: android.arch.lifecycle.i */
public class C0021i {
    /* renamed from: a */
    private Map<String, Integer> f39a = new HashMap();
}
