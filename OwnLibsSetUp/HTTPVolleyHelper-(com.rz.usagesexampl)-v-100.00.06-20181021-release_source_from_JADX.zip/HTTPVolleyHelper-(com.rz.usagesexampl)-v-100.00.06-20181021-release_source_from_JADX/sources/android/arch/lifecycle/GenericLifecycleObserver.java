package android.arch.lifecycle;

import android.arch.lifecycle.C0015c.C0013a;

public interface GenericLifecycleObserver extends C0016d {
    /* renamed from: a */
    void mo420a(C0017e c0017e, C0013a c0013a);
}
