package android.arch.p000a.p001a;

/* renamed from: android.arch.a.a.c */
public abstract class C0002c {
    /* renamed from: a */
    public abstract void mo1a(Runnable runnable);

    /* renamed from: b */
    public abstract void mo2b(Runnable runnable);

    /* renamed from: b */
    public abstract boolean mo3b();
}
