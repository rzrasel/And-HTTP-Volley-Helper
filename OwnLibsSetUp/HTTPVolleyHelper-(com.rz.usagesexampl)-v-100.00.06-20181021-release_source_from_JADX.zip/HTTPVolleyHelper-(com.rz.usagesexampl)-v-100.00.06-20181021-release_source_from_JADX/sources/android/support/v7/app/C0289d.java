package android.support.v7.app;

import android.support.v7.view.C0308b;
import android.support.v7.view.C0308b.C0307a;

/* renamed from: android.support.v7.app.d */
public interface C0289d {
    /* renamed from: a */
    C0308b mo146a(C0307a c0307a);

    /* renamed from: a */
    void mo147a(C0308b c0308b);

    /* renamed from: b */
    void mo148b(C0308b c0308b);
}
