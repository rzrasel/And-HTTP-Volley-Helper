package android.support.v7.view.menu;

/* renamed from: android.support.v7.view.menu.d */
class C0318d<T> {
    /* renamed from: b */
    final T f1083b;

    C0318d(T t) {
        if (t != null) {
            this.f1083b = t;
            return;
        }
        throw new IllegalArgumentException("Wrapped Object can not be null.");
    }
}
