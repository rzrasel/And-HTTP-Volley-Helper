package android.support.v7.view;

/* renamed from: android.support.v7.view.c */
public interface C0309c {
    /* renamed from: a */
    void mo235a();

    /* renamed from: b */
    void mo236b();
}
