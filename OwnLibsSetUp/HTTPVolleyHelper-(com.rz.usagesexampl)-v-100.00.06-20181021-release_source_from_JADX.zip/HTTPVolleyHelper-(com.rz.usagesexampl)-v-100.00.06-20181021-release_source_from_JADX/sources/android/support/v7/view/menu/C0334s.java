package android.support.v7.view.menu;

import android.widget.ListView;

/* renamed from: android.support.v7.view.menu.s */
public interface C0334s {
    /* renamed from: a */
    void mo286a();

    /* renamed from: c */
    void mo287c();

    /* renamed from: d */
    boolean mo288d();

    /* renamed from: e */
    ListView mo289e();
}
