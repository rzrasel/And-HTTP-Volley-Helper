package android.support.v7.view.menu;

/* renamed from: android.support.v7.view.menu.p */
public interface C0332p {

    /* renamed from: android.support.v7.view.menu.p$a */
    public interface C0331a {
        /* renamed from: a */
        void mo194a(C0601j c0601j, int i);

        /* renamed from: a */
        boolean mo195a();

        C0601j getItemData();
    }

    /* renamed from: a */
    void mo192a(C0598h c0598h);
}
