package android.support.v7.view.menu;

import android.content.Context;

/* renamed from: android.support.v7.view.menu.o */
public interface C0330o {

    /* renamed from: android.support.v7.view.menu.o$a */
    public interface C0329a {
        /* renamed from: a */
        void mo140a(C0598h c0598h, boolean z);

        /* renamed from: a */
        boolean mo141a(C0598h c0598h);
    }

    /* renamed from: a */
    void mo220a(Context context, C0598h c0598h);

    /* renamed from: a */
    void mo221a(C0598h c0598h, boolean z);

    /* renamed from: a */
    void mo222a(C0329a c0329a);

    /* renamed from: a */
    boolean mo223a(C0598h c0598h, C0601j c0601j);

    /* renamed from: a */
    boolean mo224a(C0762u c0762u);

    /* renamed from: b */
    void mo225b(boolean z);

    /* renamed from: b */
    boolean mo226b();

    /* renamed from: b */
    boolean mo227b(C0598h c0598h, C0601j c0601j);
}
