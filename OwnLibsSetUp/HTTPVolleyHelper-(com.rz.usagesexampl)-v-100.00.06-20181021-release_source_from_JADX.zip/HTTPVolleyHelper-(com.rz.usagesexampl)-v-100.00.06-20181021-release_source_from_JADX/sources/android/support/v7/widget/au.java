package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

class au {
    /* renamed from: a */
    public ColorStateList f1344a;
    /* renamed from: b */
    public Mode f1345b;
    /* renamed from: c */
    public boolean f1346c;
    /* renamed from: d */
    public boolean f1347d;

    au() {
    }

    /* renamed from: a */
    void m1475a() {
        this.f1344a = null;
        this.f1347d = false;
        this.f1345b = null;
        this.f1346c = false;
    }
}
