package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.p017g.C0234s;
import android.support.v7.view.menu.C0330o.C0329a;
import android.support.v7.view.menu.C0598h.C0325a;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window.Callback;

public interface ae {
    /* renamed from: a */
    C0234s mo300a(int i, long j);

    /* renamed from: a */
    ViewGroup mo301a();

    /* renamed from: a */
    void mo302a(int i);

    /* renamed from: a */
    void mo303a(Drawable drawable);

    /* renamed from: a */
    void mo304a(C0329a c0329a, C0325a c0325a);

    /* renamed from: a */
    void mo305a(ap apVar);

    /* renamed from: a */
    void mo306a(Menu menu, C0329a c0329a);

    /* renamed from: a */
    void mo307a(Callback callback);

    /* renamed from: a */
    void mo308a(CharSequence charSequence);

    /* renamed from: a */
    void mo309a(boolean z);

    /* renamed from: b */
    Context mo310b();

    /* renamed from: b */
    void mo311b(int i);

    /* renamed from: b */
    void mo312b(boolean z);

    /* renamed from: c */
    void mo313c(int i);

    /* renamed from: c */
    boolean mo314c();

    /* renamed from: d */
    void mo315d();

    /* renamed from: d */
    void mo316d(int i);

    /* renamed from: e */
    CharSequence mo317e();

    /* renamed from: f */
    void mo318f();

    /* renamed from: g */
    void mo319g();

    /* renamed from: h */
    boolean mo320h();

    /* renamed from: i */
    boolean mo321i();

    /* renamed from: j */
    boolean mo322j();

    /* renamed from: k */
    boolean mo323k();

    /* renamed from: l */
    boolean mo324l();

    /* renamed from: m */
    void mo325m();

    /* renamed from: n */
    void mo326n();

    /* renamed from: o */
    int mo327o();

    /* renamed from: p */
    int mo328p();

    /* renamed from: q */
    Menu mo329q();
}
