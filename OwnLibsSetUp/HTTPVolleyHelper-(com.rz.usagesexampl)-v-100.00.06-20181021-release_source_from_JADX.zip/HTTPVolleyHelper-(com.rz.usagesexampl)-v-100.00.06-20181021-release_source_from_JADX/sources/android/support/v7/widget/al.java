package android.support.v7.widget;

import android.support.v7.view.menu.C0598h;
import android.view.MenuItem;

public interface al {
    /* renamed from: a */
    void mo228a(C0598h c0598h, MenuItem menuItem);

    /* renamed from: b */
    void mo229b(C0598h c0598h, MenuItem menuItem);
}
