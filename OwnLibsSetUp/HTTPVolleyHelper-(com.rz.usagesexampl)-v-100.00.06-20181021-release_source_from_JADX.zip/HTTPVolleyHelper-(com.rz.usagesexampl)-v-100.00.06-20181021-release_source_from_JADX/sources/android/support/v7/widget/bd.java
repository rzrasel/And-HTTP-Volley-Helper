package android.support.v7.widget;

public interface bd {
    /* renamed from: a */
    CharSequence m1516a();
}
