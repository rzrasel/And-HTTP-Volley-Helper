package android.support.v7.widget;

import android.graphics.Rect;

public interface ah {

    /* renamed from: android.support.v7.widget.ah$a */
    public interface C0363a {
        /* renamed from: a */
        void mo137a(Rect rect);
    }

    void setOnFitSystemWindowsListener(C0363a c0363a);
}
