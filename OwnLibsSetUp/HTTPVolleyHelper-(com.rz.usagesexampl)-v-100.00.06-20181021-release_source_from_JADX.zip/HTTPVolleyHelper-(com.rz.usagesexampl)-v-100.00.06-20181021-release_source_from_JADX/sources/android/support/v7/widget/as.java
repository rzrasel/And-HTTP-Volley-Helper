package android.support.v7.widget;

import android.content.res.Resources.Theme;
import android.widget.SpinnerAdapter;

public interface as extends SpinnerAdapter {
    /* renamed from: a */
    Theme m1471a();

    /* renamed from: a */
    void m1472a(Theme theme);
}
