package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v4.p017g.C0213d;
import android.support.v4.p017g.C0227p;
import android.support.v7.p020a.C0270a.C0269j;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class aj extends ViewGroup {
    /* renamed from: a */
    private boolean f1274a;
    /* renamed from: b */
    private int f1275b;
    /* renamed from: c */
    private int f1276c;
    /* renamed from: d */
    private int f1277d;
    /* renamed from: e */
    private int f1278e;
    /* renamed from: f */
    private int f1279f;
    /* renamed from: g */
    private float f1280g;
    /* renamed from: h */
    private boolean f1281h;
    /* renamed from: i */
    private int[] f1282i;
    /* renamed from: j */
    private int[] f1283j;
    /* renamed from: k */
    private Drawable f1284k;
    /* renamed from: l */
    private int f1285l;
    /* renamed from: m */
    private int f1286m;
    /* renamed from: n */
    private int f1287n;
    /* renamed from: o */
    private int f1288o;

    /* renamed from: android.support.v7.widget.aj$a */
    public static class C0366a extends MarginLayoutParams {
        /* renamed from: g */
        public float f1272g;
        /* renamed from: h */
        public int f1273h;

        public C0366a(int i, int i2) {
            super(i, i2);
            this.f1273h = -1;
            this.f1272g = 0.0f;
        }

        public C0366a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1273h = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0269j.LinearLayoutCompat_Layout);
            this.f1272g = obtainStyledAttributes.getFloat(C0269j.LinearLayoutCompat_Layout_android_layout_weight, 0.0f);
            this.f1273h = obtainStyledAttributes.getInt(C0269j.LinearLayoutCompat_Layout_android_layout_gravity, -1);
            obtainStyledAttributes.recycle();
        }

        public C0366a(LayoutParams layoutParams) {
            super(layoutParams);
            this.f1273h = -1;
        }
    }

    public aj(Context context) {
        this(context, null);
    }

    public aj(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public aj(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1274a = true;
        this.f1275b = -1;
        this.f1276c = 0;
        this.f1278e = 8388659;
        aw a = aw.m1478a(context, attributeSet, C0269j.LinearLayoutCompat, i, 0);
        int a2 = a.m1480a(C0269j.LinearLayoutCompat_android_orientation, -1);
        if (a2 >= 0) {
            setOrientation(a2);
        }
        a2 = a.m1480a(C0269j.LinearLayoutCompat_android_gravity, -1);
        if (a2 >= 0) {
            setGravity(a2);
        }
        boolean a3 = a.m1484a(C0269j.LinearLayoutCompat_android_baselineAligned, true);
        if (!a3) {
            setBaselineAligned(a3);
        }
        this.f1280g = a.m1479a(C0269j.LinearLayoutCompat_android_weightSum, -1.0f);
        this.f1275b = a.m1480a(C0269j.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
        this.f1281h = a.m1484a(C0269j.LinearLayoutCompat_measureWithLargestChild, false);
        setDividerDrawable(a.m1482a(C0269j.LinearLayoutCompat_divider));
        this.f1287n = a.m1480a(C0269j.LinearLayoutCompat_showDividers, 0);
        this.f1288o = a.m1491e(C0269j.LinearLayoutCompat_dividerPadding, 0);
        a.m1483a();
    }

    /* renamed from: a */
    private void m1427a(View view, int i, int i2, int i3, int i4) {
        view.layout(i, i2, i3 + i, i4 + i2);
    }

    /* renamed from: c */
    private void m1428c(int i, int i2) {
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View b = m1440b(i3);
            if (b.getVisibility() != 8) {
                C0366a c0366a = (C0366a) b.getLayoutParams();
                if (c0366a.width == -1) {
                    int i4 = c0366a.height;
                    c0366a.height = b.getMeasuredHeight();
                    measureChildWithMargins(b, makeMeasureSpec, 0, i2, 0);
                    c0366a.height = i4;
                }
            }
        }
    }

    /* renamed from: d */
    private void m1429d(int i, int i2) {
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View b = m1440b(i3);
            if (b.getVisibility() != 8) {
                C0366a c0366a = (C0366a) b.getLayoutParams();
                if (c0366a.height == -1) {
                    int i4 = c0366a.width;
                    c0366a.width = b.getMeasuredWidth();
                    measureChildWithMargins(b, i2, 0, makeMeasureSpec, 0);
                    c0366a.width = i4;
                }
            }
        }
    }

    /* renamed from: a */
    int m1430a(View view) {
        return 0;
    }

    /* renamed from: a */
    int m1431a(View view, int i) {
        return 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    void m1432a(int r41, int r42) {
        /*
        r40 = this;
        r7 = r40;
        r8 = r41;
        r9 = r42;
        r10 = 0;
        r7.f1279f = r10;
        r11 = r40.getVirtualChildCount();
        r12 = android.view.View.MeasureSpec.getMode(r41);
        r13 = android.view.View.MeasureSpec.getMode(r42);
        r14 = r7.f1275b;
        r15 = r7.f1281h;
        r16 = 0;
        r17 = 1;
        r0 = 0;
        r1 = 0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        r5 = 0;
        r6 = 0;
        r18 = 0;
        r19 = 1;
        r20 = 0;
    L_0x002a:
        r10 = 8;
        r22 = r4;
        if (r6 >= r11) goto L_0x019d;
    L_0x0030:
        r4 = r7.m1440b(r6);
        if (r4 != 0) goto L_0x0047;
    L_0x0036:
        r4 = r7.f1279f;
        r10 = r7.m1446d(r6);
        r4 = r4 + r10;
        r7.f1279f = r4;
        r32 = r11;
        r31 = r13;
        r4 = r22;
        goto L_0x0191;
    L_0x0047:
        r24 = r1;
        r1 = r4.getVisibility();
        if (r1 != r10) goto L_0x005e;
    L_0x004f:
        r1 = r7.m1431a(r4, r6);
        r6 = r6 + r1;
        r32 = r11;
        r31 = r13;
        r4 = r22;
        r1 = r24;
        goto L_0x0191;
    L_0x005e:
        r1 = r7.m1445c(r6);
        if (r1 == 0) goto L_0x006b;
    L_0x0064:
        r1 = r7.f1279f;
        r10 = r7.f1286m;
        r1 = r1 + r10;
        r7.f1279f = r1;
    L_0x006b:
        r1 = r4.getLayoutParams();
        r10 = r1;
        r10 = (android.support.v7.widget.aj.C0366a) r10;
        r1 = r10.f1272g;
        r25 = r0 + r1;
        r1 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r13 != r1) goto L_0x00a7;
    L_0x007a:
        r0 = r10.height;
        if (r0 != 0) goto L_0x00a7;
    L_0x007e:
        r0 = r10.f1272g;
        r0 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1));
        if (r0 <= 0) goto L_0x00a7;
    L_0x0084:
        r0 = r7.f1279f;
        r1 = r10.topMargin;
        r1 = r1 + r0;
        r26 = r2;
        r2 = r10.bottomMargin;
        r1 = r1 + r2;
        r0 = java.lang.Math.max(r0, r1);
        r7.f1279f = r0;
        r0 = r3;
        r3 = r4;
        r33 = r5;
        r32 = r11;
        r31 = r13;
        r13 = r22;
        r8 = r24;
        r29 = r26;
        r18 = 1;
        r11 = r6;
        goto L_0x0117;
    L_0x00a7:
        r26 = r2;
        r0 = r10.height;
        if (r0 != 0) goto L_0x00b8;
    L_0x00ad:
        r0 = r10.f1272g;
        r0 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1));
        if (r0 <= 0) goto L_0x00b8;
    L_0x00b3:
        r0 = -2;
        r10.height = r0;
        r2 = 0;
        goto L_0x00ba;
    L_0x00b8:
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
    L_0x00ba:
        r23 = 0;
        r0 = (r25 > r16 ? 1 : (r25 == r16 ? 0 : -1));
        if (r0 != 0) goto L_0x00c5;
    L_0x00c0:
        r0 = r7.f1279f;
        r27 = r0;
        goto L_0x00c7;
    L_0x00c5:
        r27 = 0;
    L_0x00c7:
        r0 = r40;
        r8 = r24;
        r24 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r1 = r4;
        r28 = r2;
        r29 = r26;
        r2 = r6;
        r9 = r3;
        r3 = r41;
        r30 = r4;
        r32 = r11;
        r31 = r13;
        r13 = r22;
        r11 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r4 = r23;
        r33 = r5;
        r5 = r42;
        r11 = r6;
        r6 = r27;
        r0.m1436a(r1, r2, r3, r4, r5, r6);
        r0 = r28;
        r1 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r0 == r1) goto L_0x00f4;
    L_0x00f2:
        r10.height = r0;
    L_0x00f4:
        r0 = r30.getMeasuredHeight();
        r1 = r7.f1279f;
        r2 = r1 + r0;
        r3 = r10.topMargin;
        r2 = r2 + r3;
        r3 = r10.bottomMargin;
        r2 = r2 + r3;
        r3 = r30;
        r4 = r7.m1437b(r3);
        r2 = r2 + r4;
        r1 = java.lang.Math.max(r1, r2);
        r7.f1279f = r1;
        if (r15 == 0) goto L_0x0116;
    L_0x0111:
        r0 = java.lang.Math.max(r0, r9);
        goto L_0x0117;
    L_0x0116:
        r0 = r9;
    L_0x0117:
        if (r14 < 0) goto L_0x0121;
    L_0x0119:
        r6 = r11 + 1;
        if (r14 != r6) goto L_0x0121;
    L_0x011d:
        r1 = r7.f1279f;
        r7.f1276c = r1;
    L_0x0121:
        if (r11 >= r14) goto L_0x0132;
    L_0x0123:
        r1 = r10.f1272g;
        r1 = (r1 > r16 ? 1 : (r1 == r16 ? 0 : -1));
        if (r1 > 0) goto L_0x012a;
    L_0x0129:
        goto L_0x0132;
    L_0x012a:
        r0 = new java.lang.RuntimeException;
        r1 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.";
        r0.<init>(r1);
        throw r0;
    L_0x0132:
        r1 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r12 == r1) goto L_0x013f;
    L_0x0136:
        r1 = r10.width;
        r2 = -1;
        if (r1 != r2) goto L_0x013f;
    L_0x013b:
        r1 = 1;
        r20 = 1;
        goto L_0x0140;
    L_0x013f:
        r1 = 0;
    L_0x0140:
        r2 = r10.leftMargin;
        r4 = r10.rightMargin;
        r2 = r2 + r4;
        r4 = r3.getMeasuredWidth();
        r4 = r4 + r2;
        r5 = r29;
        r5 = java.lang.Math.max(r5, r4);
        r6 = r3.getMeasuredState();
        r6 = android.view.View.combineMeasuredStates(r8, r6);
        if (r19 == 0) goto L_0x0161;
    L_0x015a:
        r8 = r10.width;
        r9 = -1;
        if (r8 != r9) goto L_0x0161;
    L_0x015f:
        r8 = 1;
        goto L_0x0162;
    L_0x0161:
        r8 = 0;
    L_0x0162:
        r9 = r10.f1272g;
        r9 = (r9 > r16 ? 1 : (r9 == r16 ? 0 : -1));
        if (r9 <= 0) goto L_0x0174;
    L_0x0168:
        if (r1 == 0) goto L_0x016b;
    L_0x016a:
        goto L_0x016c;
    L_0x016b:
        r2 = r4;
    L_0x016c:
        r4 = java.lang.Math.max(r13, r2);
        r13 = r4;
        r1 = r33;
        goto L_0x017f;
    L_0x0174:
        if (r1 == 0) goto L_0x0179;
    L_0x0176:
        r1 = r33;
        goto L_0x017b;
    L_0x0179:
        r2 = r4;
        goto L_0x0176;
    L_0x017b:
        r1 = java.lang.Math.max(r1, r2);
    L_0x017f:
        r2 = r7.m1431a(r3, r11);
        r2 = r2 + r11;
        r3 = r0;
        r19 = r8;
        r4 = r13;
        r0 = r25;
        r39 = r5;
        r5 = r1;
        r1 = r6;
        r6 = r2;
        r2 = r39;
    L_0x0191:
        r6 = r6 + 1;
        r13 = r31;
        r11 = r32;
        r8 = r41;
        r9 = r42;
        goto L_0x002a;
    L_0x019d:
        r8 = r1;
        r9 = r3;
        r1 = r5;
        r32 = r11;
        r31 = r13;
        r13 = r22;
        r5 = r2;
        r2 = r7.f1279f;
        if (r2 <= 0) goto L_0x01bb;
    L_0x01ab:
        r2 = r32;
        r3 = r7.m1445c(r2);
        if (r3 == 0) goto L_0x01bd;
    L_0x01b3:
        r3 = r7.f1279f;
        r4 = r7.f1286m;
        r3 = r3 + r4;
        r7.f1279f = r3;
        goto L_0x01bd;
    L_0x01bb:
        r2 = r32;
    L_0x01bd:
        if (r15 == 0) goto L_0x020b;
    L_0x01bf:
        r3 = r31;
        r4 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r3 == r4) goto L_0x01c7;
    L_0x01c5:
        if (r3 != 0) goto L_0x020d;
    L_0x01c7:
        r4 = 0;
        r7.f1279f = r4;
        r4 = 0;
    L_0x01cb:
        if (r4 >= r2) goto L_0x020d;
    L_0x01cd:
        r6 = r7.m1440b(r4);
        if (r6 != 0) goto L_0x01dd;
    L_0x01d3:
        r6 = r7.f1279f;
        r11 = r7.m1446d(r4);
        r6 = r6 + r11;
    L_0x01da:
        r7.f1279f = r6;
        goto L_0x0206;
    L_0x01dd:
        r11 = r6.getVisibility();
        if (r11 != r10) goto L_0x01e9;
    L_0x01e3:
        r6 = r7.m1431a(r6, r4);
        r4 = r4 + r6;
        goto L_0x0206;
    L_0x01e9:
        r11 = r6.getLayoutParams();
        r11 = (android.support.v7.widget.aj.C0366a) r11;
        r14 = r7.f1279f;
        r21 = r14 + r9;
        r10 = r11.topMargin;
        r21 = r21 + r10;
        r10 = r11.bottomMargin;
        r21 = r21 + r10;
        r6 = r7.m1437b(r6);
        r6 = r21 + r6;
        r6 = java.lang.Math.max(r14, r6);
        goto L_0x01da;
    L_0x0206:
        r4 = r4 + 1;
        r10 = 8;
        goto L_0x01cb;
    L_0x020b:
        r3 = r31;
    L_0x020d:
        r4 = r7.f1279f;
        r6 = r40.getPaddingTop();
        r10 = r40.getPaddingBottom();
        r6 = r6 + r10;
        r4 = r4 + r6;
        r7.f1279f = r4;
        r4 = r7.f1279f;
        r6 = r40.getSuggestedMinimumHeight();
        r4 = java.lang.Math.max(r4, r6);
        r10 = r9;
        r6 = r42;
        r9 = 0;
        r4 = android.view.View.resolveSizeAndState(r4, r6, r9);
        r9 = 16777215; // 0xffffff float:2.3509886E-38 double:8.2890456E-317;
        r9 = r9 & r4;
        r11 = r7.f1279f;
        r9 = r9 - r11;
        if (r18 != 0) goto L_0x027e;
    L_0x0236:
        if (r9 == 0) goto L_0x023d;
    L_0x0238:
        r11 = (r0 > r16 ? 1 : (r0 == r16 ? 0 : -1));
        if (r11 <= 0) goto L_0x023d;
    L_0x023c:
        goto L_0x027e;
    L_0x023d:
        r0 = java.lang.Math.max(r1, r13);
        if (r15 == 0) goto L_0x0279;
    L_0x0243:
        r1 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r3 == r1) goto L_0x0279;
    L_0x0247:
        r1 = 0;
    L_0x0248:
        if (r1 >= r2) goto L_0x0279;
    L_0x024a:
        r3 = r7.m1440b(r1);
        if (r3 == 0) goto L_0x0276;
    L_0x0250:
        r9 = r3.getVisibility();
        r11 = 8;
        if (r9 != r11) goto L_0x0259;
    L_0x0258:
        goto L_0x0276;
    L_0x0259:
        r9 = r3.getLayoutParams();
        r9 = (android.support.v7.widget.aj.C0366a) r9;
        r9 = r9.f1272g;
        r9 = (r9 > r16 ? 1 : (r9 == r16 ? 0 : -1));
        if (r9 <= 0) goto L_0x0276;
    L_0x0265:
        r9 = r3.getMeasuredWidth();
        r11 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r11);
        r13 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r11);
        r3.measure(r9, r13);
    L_0x0276:
        r1 = r1 + 1;
        goto L_0x0248;
    L_0x0279:
        r1 = r8;
        r11 = r41;
        goto L_0x0373;
    L_0x027e:
        r10 = r7.f1280g;
        r10 = (r10 > r16 ? 1 : (r10 == r16 ? 0 : -1));
        if (r10 <= 0) goto L_0x0286;
    L_0x0284:
        r0 = r7.f1280g;
    L_0x0286:
        r10 = 0;
        r7.f1279f = r10;
        r11 = r0;
        r0 = 0;
        r39 = r8;
        r8 = r1;
        r1 = r39;
    L_0x0290:
        if (r0 >= r2) goto L_0x0362;
    L_0x0292:
        r13 = r7.m1440b(r0);
        r14 = r13.getVisibility();
        r15 = 8;
        if (r14 != r15) goto L_0x02a5;
    L_0x029e:
        r38 = r3;
        r10 = r11;
        r11 = r41;
        goto L_0x035a;
    L_0x02a5:
        r14 = r13.getLayoutParams();
        r14 = (android.support.v7.widget.aj.C0366a) r14;
        r10 = r14.f1272g;
        r18 = (r10 > r16 ? 1 : (r10 == r16 ? 0 : -1));
        if (r18 <= 0) goto L_0x0301;
    L_0x02b1:
        r15 = (float) r9;
        r15 = r15 * r10;
        r15 = r15 / r11;
        r15 = (int) r15;
        r11 = r11 - r10;
        r9 = r9 - r15;
        r10 = r40.getPaddingLeft();
        r18 = r40.getPaddingRight();
        r10 = r10 + r18;
        r34 = r9;
        r9 = r14.leftMargin;
        r10 = r10 + r9;
        r9 = r14.rightMargin;
        r10 = r10 + r9;
        r9 = r14.width;
        r35 = r11;
        r11 = r41;
        r9 = getChildMeasureSpec(r11, r10, r9);
        r10 = r14.height;
        if (r10 != 0) goto L_0x02e0;
    L_0x02d8:
        r10 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r3 == r10) goto L_0x02dd;
    L_0x02dc:
        goto L_0x02e2;
    L_0x02dd:
        if (r15 <= 0) goto L_0x02ea;
    L_0x02df:
        goto L_0x02eb;
    L_0x02e0:
        r10 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
    L_0x02e2:
        r18 = r13.getMeasuredHeight();
        r15 = r18 + r15;
        if (r15 >= 0) goto L_0x02eb;
    L_0x02ea:
        r15 = 0;
    L_0x02eb:
        r15 = android.view.View.MeasureSpec.makeMeasureSpec(r15, r10);
        r13.measure(r9, r15);
        r9 = r13.getMeasuredState();
        r9 = r9 & -256;
        r1 = android.view.View.combineMeasuredStates(r1, r9);
        r9 = r34;
        r10 = r35;
        goto L_0x0304;
    L_0x0301:
        r10 = r11;
        r11 = r41;
    L_0x0304:
        r15 = r14.leftMargin;
        r36 = r1;
        r1 = r14.rightMargin;
        r15 = r15 + r1;
        r1 = r13.getMeasuredWidth();
        r1 = r1 + r15;
        r5 = java.lang.Math.max(r5, r1);
        r37 = r1;
        r1 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r12 == r1) goto L_0x0323;
    L_0x031a:
        r1 = r14.width;
        r38 = r3;
        r3 = -1;
        if (r1 != r3) goto L_0x0326;
    L_0x0321:
        r1 = 1;
        goto L_0x0327;
    L_0x0323:
        r38 = r3;
        r3 = -1;
    L_0x0326:
        r1 = 0;
    L_0x0327:
        if (r1 == 0) goto L_0x032a;
    L_0x0329:
        goto L_0x032c;
    L_0x032a:
        r15 = r37;
    L_0x032c:
        r1 = java.lang.Math.max(r8, r15);
        if (r19 == 0) goto L_0x0338;
    L_0x0332:
        r8 = r14.width;
        if (r8 != r3) goto L_0x0338;
    L_0x0336:
        r8 = 1;
        goto L_0x0339;
    L_0x0338:
        r8 = 0;
    L_0x0339:
        r15 = r7.f1279f;
        r18 = r13.getMeasuredHeight();
        r18 = r15 + r18;
        r3 = r14.topMargin;
        r18 = r18 + r3;
        r3 = r14.bottomMargin;
        r18 = r18 + r3;
        r3 = r7.m1437b(r13);
        r3 = r18 + r3;
        r3 = java.lang.Math.max(r15, r3);
        r7.f1279f = r3;
        r19 = r8;
        r8 = r1;
        r1 = r36;
    L_0x035a:
        r0 = r0 + 1;
        r11 = r10;
        r3 = r38;
        r10 = 0;
        goto L_0x0290;
    L_0x0362:
        r11 = r41;
        r0 = r7.f1279f;
        r3 = r40.getPaddingTop();
        r9 = r40.getPaddingBottom();
        r3 = r3 + r9;
        r0 = r0 + r3;
        r7.f1279f = r0;
        r0 = r8;
    L_0x0373:
        if (r19 != 0) goto L_0x037a;
    L_0x0375:
        r3 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r12 == r3) goto L_0x037a;
    L_0x0379:
        goto L_0x037b;
    L_0x037a:
        r0 = r5;
    L_0x037b:
        r3 = r40.getPaddingLeft();
        r5 = r40.getPaddingRight();
        r3 = r3 + r5;
        r0 = r0 + r3;
        r3 = r40.getSuggestedMinimumWidth();
        r0 = java.lang.Math.max(r0, r3);
        r0 = android.view.View.resolveSizeAndState(r0, r11, r1);
        r7.setMeasuredDimension(r0, r4);
        if (r20 == 0) goto L_0x0399;
    L_0x0396:
        r7.m1428c(r2, r6);
    L_0x0399:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.aj.a(int, int):void");
    }

    /* renamed from: a */
    void m1433a(int i, int i2, int i3, int i4) {
        int paddingLeft = getPaddingLeft();
        int i5 = i3 - i;
        int paddingRight = i5 - getPaddingRight();
        int paddingRight2 = (i5 - paddingLeft) - getPaddingRight();
        int virtualChildCount = getVirtualChildCount();
        i5 = this.f1278e & C0269j.AppCompatTheme_windowActionModeOverlay;
        int i6 = this.f1278e & 8388615;
        int paddingTop = i5 != 16 ? i5 != 80 ? getPaddingTop() : ((getPaddingTop() + i4) - i2) - r6.f1279f : (((i4 - i2) - r6.f1279f) / 2) + getPaddingTop();
        int i7 = 0;
        while (i7 < virtualChildCount) {
            View b = m1440b(i7);
            if (b == null) {
                paddingTop += m1446d(i7);
            } else if (b.getVisibility() != 8) {
                int measuredWidth = b.getMeasuredWidth();
                int measuredHeight = b.getMeasuredHeight();
                C0366a c0366a = (C0366a) b.getLayoutParams();
                int i8 = c0366a.f1273h;
                if (i8 < 0) {
                    i8 = i6;
                }
                i8 = C0213d.m797a(i8, C0227p.m876b(this)) & 7;
                if (i8 == 1) {
                    i8 = (((paddingRight2 - measuredWidth) / 2) + paddingLeft) + c0366a.leftMargin;
                    i8 -= c0366a.rightMargin;
                } else if (i8 != 5) {
                    i8 = c0366a.leftMargin + paddingLeft;
                } else {
                    i8 = paddingRight - measuredWidth;
                    i8 -= c0366a.rightMargin;
                }
                i5 = i8;
                if (m1445c(i7)) {
                    paddingTop += r6.f1286m;
                }
                int i9 = paddingTop + c0366a.topMargin;
                C0366a c0366a2 = c0366a;
                m1427a(b, i5, i9 + m1430a(b), measuredWidth, measuredHeight);
                i7 += m1431a(b, i7);
                paddingTop = i9 + ((measuredHeight + c0366a2.bottomMargin) + m1437b(b));
            }
            i7++;
        }
    }

    /* renamed from: a */
    void m1434a(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        int i = 0;
        while (i < virtualChildCount) {
            View b = m1440b(i);
            if (!(b == null || b.getVisibility() == 8 || !m1445c(i))) {
                m1435a(canvas, (b.getTop() - ((C0366a) b.getLayoutParams()).topMargin) - this.f1286m);
            }
            i++;
        }
        if (m1445c(virtualChildCount)) {
            View b2 = m1440b(virtualChildCount - 1);
            if (b2 == null) {
                virtualChildCount = (getHeight() - getPaddingBottom()) - this.f1286m;
            } else {
                virtualChildCount = b2.getBottom() + ((C0366a) b2.getLayoutParams()).bottomMargin;
            }
            m1435a(canvas, virtualChildCount);
        }
    }

    /* renamed from: a */
    void m1435a(Canvas canvas, int i) {
        this.f1284k.setBounds(getPaddingLeft() + this.f1288o, i, (getWidth() - getPaddingRight()) - this.f1288o, this.f1286m + i);
        this.f1284k.draw(canvas);
    }

    /* renamed from: a */
    void m1436a(View view, int i, int i2, int i3, int i4, int i5) {
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    /* renamed from: b */
    int m1437b(View view) {
        return 0;
    }

    /* renamed from: b */
    public C0366a mo263b(AttributeSet attributeSet) {
        return new C0366a(getContext(), attributeSet);
    }

    /* renamed from: b */
    protected C0366a mo264b(LayoutParams layoutParams) {
        return new C0366a(layoutParams);
    }

    /* renamed from: b */
    View m1440b(int i) {
        return getChildAt(i);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: b */
    void m1441b(int r45, int r46) {
        /*
        r44 = this;
        r7 = r44;
        r8 = r45;
        r9 = r46;
        r10 = 0;
        r7.f1279f = r10;
        r11 = r44.getVirtualChildCount();
        r12 = android.view.View.MeasureSpec.getMode(r45);
        r13 = android.view.View.MeasureSpec.getMode(r46);
        r0 = r7.f1282i;
        r14 = 4;
        if (r0 == 0) goto L_0x001e;
    L_0x001a:
        r0 = r7.f1283j;
        if (r0 != 0) goto L_0x0026;
    L_0x001e:
        r0 = new int[r14];
        r7.f1282i = r0;
        r0 = new int[r14];
        r7.f1283j = r0;
    L_0x0026:
        r15 = r7.f1282i;
        r6 = r7.f1283j;
        r16 = 3;
        r5 = -1;
        r15[r16] = r5;
        r17 = 2;
        r15[r17] = r5;
        r18 = 1;
        r15[r18] = r5;
        r15[r10] = r5;
        r6[r16] = r5;
        r6[r17] = r5;
        r6[r18] = r5;
        r6[r10] = r5;
        r4 = r7.f1274a;
        r3 = r7.f1281h;
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r12 != r2) goto L_0x004c;
    L_0x0049:
        r19 = 1;
        goto L_0x004e;
    L_0x004c:
        r19 = 0;
    L_0x004e:
        r20 = 0;
        r0 = 0;
        r1 = 0;
        r14 = 0;
        r21 = 0;
        r22 = 0;
        r23 = 0;
        r24 = 0;
        r26 = 0;
        r27 = 1;
        r28 = 0;
    L_0x0061:
        r29 = r6;
        r5 = 8;
        if (r1 >= r11) goto L_0x0203;
    L_0x0067:
        r6 = r7.m1440b(r1);
        if (r6 != 0) goto L_0x007c;
    L_0x006d:
        r5 = r7.f1279f;
        r6 = r7.m1446d(r1);
        r5 = r5 + r6;
        r7.f1279f = r5;
    L_0x0076:
        r32 = r3;
        r36 = r4;
        goto L_0x01f3;
    L_0x007c:
        r10 = r6.getVisibility();
        if (r10 != r5) goto L_0x0088;
    L_0x0082:
        r5 = r7.m1431a(r6, r1);
        r1 = r1 + r5;
        goto L_0x0076;
    L_0x0088:
        r5 = r7.m1445c(r1);
        if (r5 == 0) goto L_0x0095;
    L_0x008e:
        r5 = r7.f1279f;
        r10 = r7.f1285l;
        r5 = r5 + r10;
        r7.f1279f = r5;
    L_0x0095:
        r5 = r6.getLayoutParams();
        r10 = r5;
        r10 = (android.support.v7.widget.aj.C0366a) r10;
        r5 = r10.f1272g;
        r31 = r0 + r5;
        if (r12 != r2) goto L_0x00ea;
    L_0x00a2:
        r0 = r10.width;
        if (r0 != 0) goto L_0x00ea;
    L_0x00a6:
        r0 = r10.f1272g;
        r0 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1));
        if (r0 <= 0) goto L_0x00ea;
    L_0x00ac:
        if (r19 == 0) goto L_0x00b9;
    L_0x00ae:
        r0 = r7.f1279f;
        r5 = r10.leftMargin;
        r2 = r10.rightMargin;
        r5 = r5 + r2;
        r0 = r0 + r5;
    L_0x00b6:
        r7.f1279f = r0;
        goto L_0x00c6;
    L_0x00b9:
        r0 = r7.f1279f;
        r2 = r10.leftMargin;
        r2 = r2 + r0;
        r5 = r10.rightMargin;
        r2 = r2 + r5;
        r0 = java.lang.Math.max(r0, r2);
        goto L_0x00b6;
    L_0x00c6:
        if (r4 == 0) goto L_0x00db;
    L_0x00c8:
        r0 = 0;
        r2 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r0);
        r6.measure(r2, r2);
        r34 = r1;
        r32 = r3;
        r36 = r4;
        r3 = r6;
        r30 = -2;
        goto L_0x0163;
    L_0x00db:
        r34 = r1;
        r32 = r3;
        r36 = r4;
        r3 = r6;
        r1 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r22 = 1;
        r30 = -2;
        goto L_0x0165;
    L_0x00ea:
        r0 = r10.width;
        if (r0 != 0) goto L_0x00f9;
    L_0x00ee:
        r0 = r10.f1272g;
        r0 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1));
        if (r0 <= 0) goto L_0x00f9;
    L_0x00f4:
        r5 = -2;
        r10.width = r5;
        r2 = 0;
        goto L_0x00fc;
    L_0x00f9:
        r5 = -2;
        r2 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
    L_0x00fc:
        r0 = (r31 > r20 ? 1 : (r31 == r20 ? 0 : -1));
        if (r0 != 0) goto L_0x0105;
    L_0x0100:
        r0 = r7.f1279f;
        r30 = r0;
        goto L_0x0107;
    L_0x0105:
        r30 = 0;
    L_0x0107:
        r33 = 0;
        r0 = r44;
        r34 = r1;
        r1 = r6;
        r35 = r2;
        r2 = r34;
        r32 = r3;
        r3 = r45;
        r36 = r4;
        r4 = r30;
        r9 = -1;
        r30 = -2;
        r5 = r46;
        r37 = r6;
        r9 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r6 = r33;
        r0.m1436a(r1, r2, r3, r4, r5, r6);
        r0 = r35;
        if (r0 == r9) goto L_0x012e;
    L_0x012c:
        r10.width = r0;
    L_0x012e:
        r0 = r37.getMeasuredWidth();
        if (r19 == 0) goto L_0x0147;
    L_0x0134:
        r1 = r7.f1279f;
        r2 = r10.leftMargin;
        r2 = r2 + r0;
        r3 = r10.rightMargin;
        r2 = r2 + r3;
        r3 = r37;
        r4 = r7.m1437b(r3);
        r2 = r2 + r4;
        r1 = r1 + r2;
    L_0x0144:
        r7.f1279f = r1;
        goto L_0x015d;
    L_0x0147:
        r3 = r37;
        r1 = r7.f1279f;
        r2 = r1 + r0;
        r4 = r10.leftMargin;
        r2 = r2 + r4;
        r4 = r10.rightMargin;
        r2 = r2 + r4;
        r4 = r7.m1437b(r3);
        r2 = r2 + r4;
        r1 = java.lang.Math.max(r1, r2);
        goto L_0x0144;
    L_0x015d:
        if (r32 == 0) goto L_0x0163;
    L_0x015f:
        r14 = java.lang.Math.max(r0, r14);
    L_0x0163:
        r1 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
    L_0x0165:
        if (r13 == r1) goto L_0x0170;
    L_0x0167:
        r0 = r10.height;
        r2 = -1;
        if (r0 != r2) goto L_0x0170;
    L_0x016c:
        r0 = 1;
        r28 = 1;
        goto L_0x0171;
    L_0x0170:
        r0 = 0;
    L_0x0171:
        r2 = r10.topMargin;
        r4 = r10.bottomMargin;
        r2 = r2 + r4;
        r4 = r3.getMeasuredHeight();
        r4 = r4 + r2;
        r5 = r3.getMeasuredState();
        r6 = r26;
        r5 = android.view.View.combineMeasuredStates(r6, r5);
        if (r36 == 0) goto L_0x01b3;
    L_0x0187:
        r6 = r3.getBaseline();
        r9 = -1;
        if (r6 == r9) goto L_0x01b3;
    L_0x018e:
        r9 = r10.f1273h;
        if (r9 >= 0) goto L_0x0195;
    L_0x0192:
        r9 = r7.f1278e;
        goto L_0x0197;
    L_0x0195:
        r9 = r10.f1273h;
    L_0x0197:
        r9 = r9 & 112;
        r25 = 4;
        r9 = r9 >> 4;
        r9 = r9 & -2;
        r9 = r9 >> 1;
        r1 = r15[r9];
        r1 = java.lang.Math.max(r1, r6);
        r15[r9] = r1;
        r1 = r29[r9];
        r6 = r4 - r6;
        r1 = java.lang.Math.max(r1, r6);
        r29[r9] = r1;
    L_0x01b3:
        r1 = r21;
        r1 = java.lang.Math.max(r1, r4);
        if (r27 == 0) goto L_0x01c2;
    L_0x01bb:
        r6 = r10.height;
        r9 = -1;
        if (r6 != r9) goto L_0x01c2;
    L_0x01c0:
        r6 = 1;
        goto L_0x01c3;
    L_0x01c2:
        r6 = 0;
    L_0x01c3:
        r9 = r10.f1272g;
        r9 = (r9 > r20 ? 1 : (r9 == r20 ? 0 : -1));
        if (r9 <= 0) goto L_0x01d7;
    L_0x01c9:
        if (r0 == 0) goto L_0x01ce;
    L_0x01cb:
        r10 = r24;
        goto L_0x01d0;
    L_0x01ce:
        r2 = r4;
        goto L_0x01cb;
    L_0x01d0:
        r24 = java.lang.Math.max(r10, r2);
    L_0x01d4:
        r10 = r34;
        goto L_0x01e5;
    L_0x01d7:
        r10 = r24;
        if (r0 == 0) goto L_0x01dc;
    L_0x01db:
        r4 = r2;
    L_0x01dc:
        r2 = r23;
        r23 = java.lang.Math.max(r2, r4);
        r24 = r10;
        goto L_0x01d4;
    L_0x01e5:
        r0 = r7.m1431a(r3, r10);
        r0 = r0 + r10;
        r21 = r1;
        r26 = r5;
        r27 = r6;
        r1 = r0;
        r0 = r31;
    L_0x01f3:
        r1 = r1 + 1;
        r6 = r29;
        r3 = r32;
        r4 = r36;
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r5 = -1;
        r9 = r46;
        r10 = 0;
        goto L_0x0061;
    L_0x0203:
        r32 = r3;
        r36 = r4;
        r1 = r21;
        r2 = r23;
        r10 = r24;
        r6 = r26;
        r9 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r30 = -2;
        r3 = r7.f1279f;
        if (r3 <= 0) goto L_0x0224;
    L_0x0217:
        r3 = r7.m1445c(r11);
        if (r3 == 0) goto L_0x0224;
    L_0x021d:
        r3 = r7.f1279f;
        r4 = r7.f1285l;
        r3 = r3 + r4;
        r7.f1279f = r3;
    L_0x0224:
        r3 = r15[r18];
        r4 = -1;
        if (r3 != r4) goto L_0x023a;
    L_0x0229:
        r3 = 0;
        r5 = r15[r3];
        if (r5 != r4) goto L_0x023a;
    L_0x022e:
        r3 = r15[r17];
        if (r3 != r4) goto L_0x023a;
    L_0x0232:
        r3 = r15[r16];
        if (r3 == r4) goto L_0x0237;
    L_0x0236:
        goto L_0x023a;
    L_0x0237:
        r38 = r6;
        goto L_0x026d;
    L_0x023a:
        r3 = r15[r16];
        r4 = 0;
        r5 = r15[r4];
        r9 = r15[r18];
        r4 = r15[r17];
        r4 = java.lang.Math.max(r9, r4);
        r4 = java.lang.Math.max(r5, r4);
        r3 = java.lang.Math.max(r3, r4);
        r4 = r29[r16];
        r5 = 0;
        r9 = r29[r5];
        r5 = r29[r18];
        r38 = r6;
        r6 = r29[r17];
        r5 = java.lang.Math.max(r5, r6);
        r5 = java.lang.Math.max(r9, r5);
        r4 = java.lang.Math.max(r4, r5);
        r3 = r3 + r4;
        r21 = java.lang.Math.max(r1, r3);
        r1 = r21;
    L_0x026d:
        if (r32 == 0) goto L_0x02d0;
    L_0x026f:
        r3 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        if (r12 == r3) goto L_0x0275;
    L_0x0273:
        if (r12 != 0) goto L_0x02d0;
    L_0x0275:
        r3 = 0;
        r7.f1279f = r3;
        r3 = 0;
    L_0x0279:
        if (r3 >= r11) goto L_0x02d0;
    L_0x027b:
        r4 = r7.m1440b(r3);
        if (r4 != 0) goto L_0x028b;
    L_0x0281:
        r4 = r7.f1279f;
        r5 = r7.m1446d(r3);
        r4 = r4 + r5;
        r7.f1279f = r4;
        goto L_0x0298;
    L_0x028b:
        r5 = r4.getVisibility();
        r6 = 8;
        if (r5 != r6) goto L_0x029b;
    L_0x0293:
        r4 = r7.m1431a(r4, r3);
        r3 = r3 + r4;
    L_0x0298:
        r39 = r1;
        goto L_0x02cb;
    L_0x029b:
        r5 = r4.getLayoutParams();
        r5 = (android.support.v7.widget.aj.C0366a) r5;
        if (r19 == 0) goto L_0x02b4;
    L_0x02a3:
        r6 = r7.f1279f;
        r9 = r5.leftMargin;
        r9 = r9 + r14;
        r5 = r5.rightMargin;
        r9 = r9 + r5;
        r4 = r7.m1437b(r4);
        r9 = r9 + r4;
        r6 = r6 + r9;
        r7.f1279f = r6;
        goto L_0x0298;
    L_0x02b4:
        r6 = r7.f1279f;
        r9 = r6 + r14;
        r39 = r1;
        r1 = r5.leftMargin;
        r9 = r9 + r1;
        r1 = r5.rightMargin;
        r9 = r9 + r1;
        r1 = r7.m1437b(r4);
        r9 = r9 + r1;
        r1 = java.lang.Math.max(r6, r9);
        r7.f1279f = r1;
    L_0x02cb:
        r3 = r3 + 1;
        r1 = r39;
        goto L_0x0279;
    L_0x02d0:
        r39 = r1;
        r1 = r7.f1279f;
        r3 = r44.getPaddingLeft();
        r4 = r44.getPaddingRight();
        r3 = r3 + r4;
        r1 = r1 + r3;
        r7.f1279f = r1;
        r1 = r7.f1279f;
        r3 = r44.getSuggestedMinimumWidth();
        r1 = java.lang.Math.max(r1, r3);
        r3 = 0;
        r1 = android.view.View.resolveSizeAndState(r1, r8, r3);
        r3 = 16777215; // 0xffffff float:2.3509886E-38 double:8.2890456E-317;
        r3 = r3 & r1;
        r4 = r7.f1279f;
        r3 = r3 - r4;
        if (r22 != 0) goto L_0x0341;
    L_0x02f8:
        if (r3 == 0) goto L_0x02ff;
    L_0x02fa:
        r5 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1));
        if (r5 <= 0) goto L_0x02ff;
    L_0x02fe:
        goto L_0x0341;
    L_0x02ff:
        r0 = java.lang.Math.max(r2, r10);
        if (r32 == 0) goto L_0x033b;
    L_0x0305:
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r12 == r2) goto L_0x033b;
    L_0x0309:
        r2 = 0;
    L_0x030a:
        if (r2 >= r11) goto L_0x033b;
    L_0x030c:
        r3 = r7.m1440b(r2);
        if (r3 == 0) goto L_0x0338;
    L_0x0312:
        r5 = r3.getVisibility();
        r6 = 8;
        if (r5 != r6) goto L_0x031b;
    L_0x031a:
        goto L_0x0338;
    L_0x031b:
        r5 = r3.getLayoutParams();
        r5 = (android.support.v7.widget.aj.C0366a) r5;
        r5 = r5.f1272g;
        r5 = (r5 > r20 ? 1 : (r5 == r20 ? 0 : -1));
        if (r5 <= 0) goto L_0x0338;
    L_0x0327:
        r5 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r6 = android.view.View.MeasureSpec.makeMeasureSpec(r14, r5);
        r9 = r3.getMeasuredHeight();
        r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r5);
        r3.measure(r6, r9);
    L_0x0338:
        r2 = r2 + 1;
        goto L_0x030a;
    L_0x033b:
        r42 = r11;
        r3 = r46;
        goto L_0x04e0;
    L_0x0341:
        r5 = r7.f1280g;
        r5 = (r5 > r20 ? 1 : (r5 == r20 ? 0 : -1));
        if (r5 <= 0) goto L_0x0349;
    L_0x0347:
        r0 = r7.f1280g;
    L_0x0349:
        r5 = -1;
        r15[r16] = r5;
        r15[r17] = r5;
        r15[r18] = r5;
        r6 = 0;
        r15[r6] = r5;
        r29[r16] = r5;
        r29[r17] = r5;
        r29[r18] = r5;
        r29[r6] = r5;
        r7.f1279f = r6;
        r10 = r2;
        r9 = r38;
        r6 = -1;
        r2 = r0;
        r0 = 0;
    L_0x0363:
        if (r0 >= r11) goto L_0x0486;
    L_0x0365:
        r14 = r7.m1440b(r0);
        if (r14 == 0) goto L_0x0475;
    L_0x036b:
        r5 = r14.getVisibility();
        r4 = 8;
        if (r5 != r4) goto L_0x0375;
    L_0x0373:
        goto L_0x0475;
    L_0x0375:
        r5 = r14.getLayoutParams();
        r5 = (android.support.v7.widget.aj.C0366a) r5;
        r4 = r5.f1272g;
        r21 = (r4 > r20 ? 1 : (r4 == r20 ? 0 : -1));
        if (r21 <= 0) goto L_0x03d5;
    L_0x0381:
        r8 = (float) r3;
        r8 = r8 * r4;
        r8 = r8 / r2;
        r8 = (int) r8;
        r2 = r2 - r4;
        r3 = r3 - r8;
        r4 = r44.getPaddingTop();
        r21 = r44.getPaddingBottom();
        r4 = r4 + r21;
        r40 = r2;
        r2 = r5.topMargin;
        r4 = r4 + r2;
        r2 = r5.bottomMargin;
        r4 = r4 + r2;
        r2 = r5.height;
        r41 = r3;
        r42 = r11;
        r3 = r46;
        r11 = -1;
        r2 = getChildMeasureSpec(r3, r4, r2);
        r4 = r5.width;
        if (r4 != 0) goto L_0x03b3;
    L_0x03ab:
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r12 == r4) goto L_0x03b0;
    L_0x03af:
        goto L_0x03b5;
    L_0x03b0:
        if (r8 <= 0) goto L_0x03bd;
    L_0x03b2:
        goto L_0x03be;
    L_0x03b3:
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
    L_0x03b5:
        r21 = r14.getMeasuredWidth();
        r8 = r21 + r8;
        if (r8 >= 0) goto L_0x03be;
    L_0x03bd:
        r8 = 0;
    L_0x03be:
        r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r4);
        r14.measure(r8, r2);
        r2 = r14.getMeasuredState();
        r4 = -16777216; // 0xffffffffff000000 float:-1.7014118E38 double:NaN;
        r2 = r2 & r4;
        r9 = android.view.View.combineMeasuredStates(r9, r2);
        r2 = r40;
        r4 = r41;
        goto L_0x03db;
    L_0x03d5:
        r4 = r3;
        r42 = r11;
        r3 = r46;
        r11 = -1;
    L_0x03db:
        if (r19 == 0) goto L_0x03fa;
    L_0x03dd:
        r8 = r7.f1279f;
        r21 = r14.getMeasuredWidth();
        r11 = r5.leftMargin;
        r21 = r21 + r11;
        r11 = r5.rightMargin;
        r21 = r21 + r11;
        r11 = r7.m1437b(r14);
        r21 = r21 + r11;
        r8 = r8 + r21;
        r7.f1279f = r8;
        r43 = r2;
    L_0x03f7:
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        goto L_0x0415;
    L_0x03fa:
        r8 = r7.f1279f;
        r11 = r14.getMeasuredWidth();
        r11 = r11 + r8;
        r43 = r2;
        r2 = r5.leftMargin;
        r11 = r11 + r2;
        r2 = r5.rightMargin;
        r11 = r11 + r2;
        r2 = r7.m1437b(r14);
        r11 = r11 + r2;
        r2 = java.lang.Math.max(r8, r11);
        r7.f1279f = r2;
        goto L_0x03f7;
    L_0x0415:
        if (r13 == r2) goto L_0x041e;
    L_0x0417:
        r2 = r5.height;
        r8 = -1;
        if (r2 != r8) goto L_0x041e;
    L_0x041c:
        r2 = 1;
        goto L_0x041f;
    L_0x041e:
        r2 = 0;
    L_0x041f:
        r8 = r5.topMargin;
        r11 = r5.bottomMargin;
        r8 = r8 + r11;
        r11 = r14.getMeasuredHeight();
        r11 = r11 + r8;
        r6 = java.lang.Math.max(r6, r11);
        if (r2 == 0) goto L_0x0430;
    L_0x042f:
        goto L_0x0431;
    L_0x0430:
        r8 = r11;
    L_0x0431:
        r2 = java.lang.Math.max(r10, r8);
        if (r27 == 0) goto L_0x043e;
    L_0x0437:
        r8 = r5.height;
        r10 = -1;
        if (r8 != r10) goto L_0x043f;
    L_0x043c:
        r8 = 1;
        goto L_0x0440;
    L_0x043e:
        r10 = -1;
    L_0x043f:
        r8 = 0;
    L_0x0440:
        if (r36 == 0) goto L_0x046d;
    L_0x0442:
        r14 = r14.getBaseline();
        if (r14 == r10) goto L_0x046d;
    L_0x0448:
        r10 = r5.f1273h;
        if (r10 >= 0) goto L_0x044f;
    L_0x044c:
        r5 = r7.f1278e;
        goto L_0x0451;
    L_0x044f:
        r5 = r5.f1273h;
    L_0x0451:
        r5 = r5 & 112;
        r21 = 4;
        r5 = r5 >> 4;
        r5 = r5 & -2;
        r5 = r5 >> 1;
        r10 = r15[r5];
        r10 = java.lang.Math.max(r10, r14);
        r15[r5] = r10;
        r10 = r29[r5];
        r11 = r11 - r14;
        r10 = java.lang.Math.max(r10, r11);
        r29[r5] = r10;
        goto L_0x046f;
    L_0x046d:
        r21 = 4;
    L_0x046f:
        r10 = r2;
        r27 = r8;
        r2 = r43;
        goto L_0x047c;
    L_0x0475:
        r4 = r3;
        r42 = r11;
        r3 = r46;
        r21 = 4;
    L_0x047c:
        r0 = r0 + 1;
        r3 = r4;
        r11 = r42;
        r5 = -1;
        r8 = r45;
        goto L_0x0363;
    L_0x0486:
        r42 = r11;
        r3 = r46;
        r0 = r7.f1279f;
        r2 = r44.getPaddingLeft();
        r4 = r44.getPaddingRight();
        r2 = r2 + r4;
        r0 = r0 + r2;
        r7.f1279f = r0;
        r0 = r15[r18];
        r2 = -1;
        if (r0 != r2) goto L_0x04ad;
    L_0x049d:
        r0 = 0;
        r4 = r15[r0];
        if (r4 != r2) goto L_0x04ad;
    L_0x04a2:
        r0 = r15[r17];
        if (r0 != r2) goto L_0x04ad;
    L_0x04a6:
        r0 = r15[r16];
        if (r0 == r2) goto L_0x04ab;
    L_0x04aa:
        goto L_0x04ad;
    L_0x04ab:
        r0 = r6;
        goto L_0x04db;
    L_0x04ad:
        r0 = r15[r16];
        r2 = 0;
        r4 = r15[r2];
        r5 = r15[r18];
        r8 = r15[r17];
        r5 = java.lang.Math.max(r5, r8);
        r4 = java.lang.Math.max(r4, r5);
        r0 = java.lang.Math.max(r0, r4);
        r4 = r29[r16];
        r2 = r29[r2];
        r5 = r29[r18];
        r8 = r29[r17];
        r5 = java.lang.Math.max(r5, r8);
        r2 = java.lang.Math.max(r2, r5);
        r2 = java.lang.Math.max(r4, r2);
        r0 = r0 + r2;
        r0 = java.lang.Math.max(r6, r0);
    L_0x04db:
        r39 = r0;
        r38 = r9;
        r0 = r10;
    L_0x04e0:
        if (r27 != 0) goto L_0x04e8;
    L_0x04e2:
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        if (r13 == r2) goto L_0x04e8;
    L_0x04e6:
        r39 = r0;
    L_0x04e8:
        r0 = r44.getPaddingTop();
        r2 = r44.getPaddingBottom();
        r0 = r0 + r2;
        r0 = r39 + r0;
        r2 = r44.getSuggestedMinimumHeight();
        r0 = java.lang.Math.max(r0, r2);
        r2 = -16777216; // 0xffffffffff000000 float:-1.7014118E38 double:NaN;
        r2 = r38 & r2;
        r1 = r1 | r2;
        r2 = r38 << 16;
        r0 = android.view.View.resolveSizeAndState(r0, r3, r2);
        r7.setMeasuredDimension(r1, r0);
        if (r28 == 0) goto L_0x0512;
    L_0x050b:
        r1 = r42;
        r0 = r45;
        r7.m1429d(r1, r0);
    L_0x0512:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.aj.b(int, int):void");
    }

    /* renamed from: b */
    void m1442b(int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        boolean a = bc.m1514a(this);
        int paddingTop = getPaddingTop();
        int i7 = i4 - i2;
        int paddingBottom = i7 - getPaddingBottom();
        int paddingBottom2 = (i7 - paddingTop) - getPaddingBottom();
        int virtualChildCount = getVirtualChildCount();
        i7 = this.f1278e & 8388615;
        int i8 = this.f1278e & C0269j.AppCompatTheme_windowActionModeOverlay;
        boolean z = this.f1274a;
        int[] iArr = this.f1282i;
        int[] iArr2 = this.f1283j;
        i7 = C0213d.m797a(i7, C0227p.m876b(this));
        int paddingLeft = i7 != 1 ? i7 != 5 ? getPaddingLeft() : ((getPaddingLeft() + i3) - i) - r6.f1279f : (((i3 - i) - r6.f1279f) / 2) + getPaddingLeft();
        if (a) {
            i5 = virtualChildCount - 1;
            i6 = -1;
        } else {
            i5 = 0;
            i6 = 1;
        }
        i7 = 0;
        while (i7 < virtualChildCount) {
            int i9;
            int i10;
            int i11;
            int i12 = i5 + (i6 * i7);
            View b = m1440b(i12);
            if (b == null) {
                paddingLeft += m1446d(i12);
            } else if (b.getVisibility() != 8) {
                int i13;
                View view;
                C0366a c0366a;
                View view2;
                int measuredWidth = b.getMeasuredWidth();
                int measuredHeight = b.getMeasuredHeight();
                C0366a c0366a2 = (C0366a) b.getLayoutParams();
                if (z) {
                    i13 = i7;
                    i9 = virtualChildCount;
                    if (c0366a2.height != -1) {
                        i7 = b.getBaseline();
                        virtualChildCount = c0366a2.f1273h;
                        if (virtualChildCount < 0) {
                            virtualChildCount = i8;
                        }
                        virtualChildCount &= C0269j.AppCompatTheme_windowActionModeOverlay;
                        i10 = i8;
                        if (virtualChildCount != 16) {
                            i7 = ((((paddingBottom2 - measuredHeight) / 2) + paddingTop) + c0366a2.topMargin) - c0366a2.bottomMargin;
                        } else if (virtualChildCount != 48) {
                            virtualChildCount = c0366a2.topMargin + paddingTop;
                            if (i7 != -1) {
                                virtualChildCount += iArr[1] - i7;
                            }
                            i7 = virtualChildCount;
                        } else if (virtualChildCount == 80) {
                            i7 = paddingTop;
                        } else {
                            virtualChildCount = (paddingBottom - measuredHeight) - c0366a2.bottomMargin;
                            if (i7 != -1) {
                                virtualChildCount -= iArr2[2] - (b.getMeasuredHeight() - i7);
                            }
                            i7 = virtualChildCount;
                        }
                        if (m1445c(i12)) {
                            paddingLeft += r6.f1285l;
                        }
                        virtualChildCount = c0366a2.leftMargin + paddingLeft;
                        view = b;
                        i8 = i12;
                        r19 = i13;
                        i11 = paddingTop;
                        c0366a = c0366a2;
                        m1427a(b, virtualChildCount + m1430a(b), i7, measuredWidth, measuredHeight);
                        view2 = view;
                        i7 = r19 + m1431a(view2, i8);
                        paddingLeft = virtualChildCount + ((measuredWidth + c0366a.rightMargin) + m1437b(view2));
                        i7++;
                        virtualChildCount = i9;
                        i8 = i10;
                        paddingTop = i11;
                    }
                } else {
                    i13 = i7;
                    i9 = virtualChildCount;
                }
                i7 = -1;
                virtualChildCount = c0366a2.f1273h;
                if (virtualChildCount < 0) {
                    virtualChildCount = i8;
                }
                virtualChildCount &= C0269j.AppCompatTheme_windowActionModeOverlay;
                i10 = i8;
                if (virtualChildCount != 16) {
                    i7 = ((((paddingBottom2 - measuredHeight) / 2) + paddingTop) + c0366a2.topMargin) - c0366a2.bottomMargin;
                } else if (virtualChildCount != 48) {
                    virtualChildCount = c0366a2.topMargin + paddingTop;
                    if (i7 != -1) {
                        virtualChildCount += iArr[1] - i7;
                    }
                    i7 = virtualChildCount;
                } else if (virtualChildCount == 80) {
                    virtualChildCount = (paddingBottom - measuredHeight) - c0366a2.bottomMargin;
                    if (i7 != -1) {
                        virtualChildCount -= iArr2[2] - (b.getMeasuredHeight() - i7);
                    }
                    i7 = virtualChildCount;
                } else {
                    i7 = paddingTop;
                }
                if (m1445c(i12)) {
                    paddingLeft += r6.f1285l;
                }
                virtualChildCount = c0366a2.leftMargin + paddingLeft;
                view = b;
                i8 = i12;
                r19 = i13;
                i11 = paddingTop;
                c0366a = c0366a2;
                m1427a(b, virtualChildCount + m1430a(b), i7, measuredWidth, measuredHeight);
                view2 = view;
                i7 = r19 + m1431a(view2, i8);
                paddingLeft = virtualChildCount + ((measuredWidth + c0366a.rightMargin) + m1437b(view2));
                i7++;
                virtualChildCount = i9;
                i8 = i10;
                paddingTop = i11;
            } else {
                r19 = i7;
            }
            i11 = paddingTop;
            i9 = virtualChildCount;
            i10 = i8;
            i7++;
            virtualChildCount = i9;
            i8 = i10;
            paddingTop = i11;
        }
    }

    /* renamed from: b */
    void m1443b(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        boolean a = bc.m1514a(this);
        int i = 0;
        while (i < virtualChildCount) {
            View b = m1440b(i);
            if (!(b == null || b.getVisibility() == 8 || !m1445c(i))) {
                C0366a c0366a = (C0366a) b.getLayoutParams();
                m1444b(canvas, a ? b.getRight() + c0366a.rightMargin : (b.getLeft() - c0366a.leftMargin) - this.f1285l);
            }
            i++;
        }
        if (m1445c(virtualChildCount)) {
            int i2;
            View b2 = m1440b(virtualChildCount - 1);
            if (b2 != null) {
                C0366a c0366a2 = (C0366a) b2.getLayoutParams();
                if (a) {
                    virtualChildCount = b2.getLeft();
                    i2 = c0366a2.leftMargin;
                } else {
                    virtualChildCount = b2.getRight() + c0366a2.rightMargin;
                    m1444b(canvas, virtualChildCount);
                }
            } else if (a) {
                virtualChildCount = getPaddingLeft();
                m1444b(canvas, virtualChildCount);
            } else {
                virtualChildCount = getWidth();
                i2 = getPaddingRight();
            }
            virtualChildCount = (virtualChildCount - i2) - this.f1285l;
            m1444b(canvas, virtualChildCount);
        }
    }

    /* renamed from: b */
    void m1444b(Canvas canvas, int i) {
        this.f1284k.setBounds(i, getPaddingTop() + this.f1288o, this.f1285l + i, (getHeight() - getPaddingBottom()) - this.f1288o);
        this.f1284k.draw(canvas);
    }

    /* renamed from: c */
    protected boolean m1445c(int i) {
        boolean z = false;
        if (i == 0) {
            if ((this.f1287n & 1) != 0) {
                z = true;
            }
            return z;
        } else if (i == getChildCount()) {
            if ((this.f1287n & 4) != 0) {
                z = true;
            }
            return z;
        } else {
            if ((this.f1287n & 2) != 0) {
                for (i--; i >= 0; i--) {
                    if (getChildAt(i).getVisibility() != 8) {
                        z = true;
                        break;
                    }
                }
            }
            return z;
        }
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0366a;
    }

    /* renamed from: d */
    int m1446d(int i) {
        return 0;
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return mo269j();
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return mo263b(attributeSet);
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return mo264b(layoutParams);
    }

    public int getBaseline() {
        if (this.f1275b < 0) {
            return super.getBaseline();
        }
        if (getChildCount() > this.f1275b) {
            View childAt = getChildAt(this.f1275b);
            int baseline = childAt.getBaseline();
            if (baseline != -1) {
                int i = this.f1276c;
                if (this.f1277d == 1) {
                    int i2 = this.f1278e & C0269j.AppCompatTheme_windowActionModeOverlay;
                    if (i2 != 48) {
                        if (i2 == 16) {
                            i += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f1279f) / 2;
                        } else if (i2 == 80) {
                            i = ((getBottom() - getTop()) - getPaddingBottom()) - this.f1279f;
                        }
                    }
                }
                return (i + ((C0366a) childAt.getLayoutParams()).topMargin) + baseline;
            } else if (this.f1275b == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        }
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
    }

    public int getBaselineAlignedChildIndex() {
        return this.f1275b;
    }

    public Drawable getDividerDrawable() {
        return this.f1284k;
    }

    public int getDividerPadding() {
        return this.f1288o;
    }

    public int getDividerWidth() {
        return this.f1285l;
    }

    public int getGravity() {
        return this.f1278e;
    }

    public int getOrientation() {
        return this.f1277d;
    }

    public int getShowDividers() {
        return this.f1287n;
    }

    int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f1280g;
    }

    /* renamed from: j */
    protected C0366a mo269j() {
        return this.f1277d == 0 ? new C0366a(-2, -2) : this.f1277d == 1 ? new C0366a(-1, -2) : null;
    }

    protected void onDraw(Canvas canvas) {
        if (this.f1284k != null) {
            if (this.f1277d == 1) {
                m1434a(canvas);
            } else {
                m1443b(canvas);
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(aj.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(aj.class.getName());
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.f1277d == 1) {
            m1433a(i, i2, i3, i4);
        } else {
            m1442b(i, i2, i3, i4);
        }
    }

    protected void onMeasure(int i, int i2) {
        if (this.f1277d == 1) {
            m1432a(i, i2);
        } else {
            m1441b(i, i2);
        }
    }

    public void setBaselineAligned(boolean z) {
        this.f1274a = z;
    }

    public void setBaselineAlignedChildIndex(int i) {
        if (i < 0 || i >= getChildCount()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("base aligned child index out of range (0, ");
            stringBuilder.append(getChildCount());
            stringBuilder.append(")");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.f1275b = i;
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable != this.f1284k) {
            this.f1284k = drawable;
            boolean z = false;
            if (drawable != null) {
                this.f1285l = drawable.getIntrinsicWidth();
                this.f1286m = drawable.getIntrinsicHeight();
            } else {
                this.f1285l = 0;
                this.f1286m = 0;
            }
            if (drawable == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setDividerPadding(int i) {
        this.f1288o = i;
    }

    public void setGravity(int i) {
        if (this.f1278e != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & C0269j.AppCompatTheme_windowActionModeOverlay) == 0) {
                i |= 48;
            }
            this.f1278e = i;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i) {
        i &= 8388615;
        if ((8388615 & this.f1278e) != i) {
            this.f1278e = i | (this.f1278e & -8388616);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z) {
        this.f1281h = z;
    }

    public void setOrientation(int i) {
        if (this.f1277d != i) {
            this.f1277d = i;
            requestLayout();
        }
    }

    public void setShowDividers(int i) {
        if (i != this.f1287n) {
            requestLayout();
        }
        this.f1287n = i;
    }

    public void setVerticalGravity(int i) {
        i &= C0269j.AppCompatTheme_windowActionModeOverlay;
        if ((this.f1278e & C0269j.AppCompatTheme_windowActionModeOverlay) != i) {
            this.f1278e = i | (this.f1278e & -113);
            requestLayout();
        }
    }

    public void setWeightSum(float f) {
        this.f1280g = Math.max(0.0f, f);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
