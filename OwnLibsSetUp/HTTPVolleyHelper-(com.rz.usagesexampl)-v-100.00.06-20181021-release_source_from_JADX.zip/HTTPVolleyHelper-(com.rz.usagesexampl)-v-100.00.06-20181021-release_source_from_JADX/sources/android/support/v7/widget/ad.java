package android.support.v7.widget;

import android.support.v7.view.menu.C0330o.C0329a;
import android.view.Menu;
import android.view.Window.Callback;

public interface ad {
    /* renamed from: a */
    void mo245a(int i);

    /* renamed from: a */
    void mo246a(Menu menu, C0329a c0329a);

    /* renamed from: e */
    boolean mo247e();

    /* renamed from: f */
    boolean mo248f();

    /* renamed from: g */
    boolean mo249g();

    /* renamed from: h */
    boolean mo250h();

    /* renamed from: i */
    boolean mo251i();

    /* renamed from: j */
    void mo252j();

    /* renamed from: k */
    void mo253k();

    void setWindowCallback(Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
