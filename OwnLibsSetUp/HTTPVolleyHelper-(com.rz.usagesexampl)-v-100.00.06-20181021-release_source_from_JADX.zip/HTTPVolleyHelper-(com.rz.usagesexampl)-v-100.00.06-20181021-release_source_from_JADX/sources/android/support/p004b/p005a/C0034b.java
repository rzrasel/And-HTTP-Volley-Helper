package android.support.p004b.p005a;

import android.graphics.drawable.Animatable;

/* renamed from: android.support.b.a.b */
public interface C0034b extends Animatable {
}
