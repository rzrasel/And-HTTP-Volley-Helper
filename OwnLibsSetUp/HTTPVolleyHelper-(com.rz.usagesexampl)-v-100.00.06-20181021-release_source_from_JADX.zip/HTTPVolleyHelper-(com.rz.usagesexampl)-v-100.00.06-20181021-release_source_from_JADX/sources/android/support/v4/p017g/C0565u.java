package android.support.v4.p017g;

import android.view.View;

/* renamed from: android.support.v4.g.u */
public class C0565u implements C0235t {
    /* renamed from: a */
    public void mo99a(View view) {
    }

    /* renamed from: b */
    public void mo100b(View view) {
    }

    /* renamed from: c */
    public void mo101c(View view) {
    }
}
