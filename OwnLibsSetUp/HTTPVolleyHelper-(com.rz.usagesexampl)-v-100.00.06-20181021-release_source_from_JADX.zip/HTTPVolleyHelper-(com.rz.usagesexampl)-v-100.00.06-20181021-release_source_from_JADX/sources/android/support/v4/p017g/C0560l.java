package android.support.v4.p017g;

import android.view.View;

/* renamed from: android.support.v4.g.l */
public interface C0560l extends C0221k {
    /* renamed from: a */
    void m2413a(View view, int i);

    /* renamed from: a */
    void m2414a(View view, int i, int i2, int i3, int i4, int i5);

    /* renamed from: a */
    void m2415a(View view, int i, int i2, int[] iArr, int i3);

    /* renamed from: a */
    boolean m2416a(View view, View view2, int i, int i2);

    /* renamed from: b */
    void m2417b(View view, View view2, int i, int i2);
}
