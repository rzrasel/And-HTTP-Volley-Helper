package android.support.v4.p017g;

/* renamed from: android.support.v4.g.i */
public interface C0559i extends C0219h {
}
