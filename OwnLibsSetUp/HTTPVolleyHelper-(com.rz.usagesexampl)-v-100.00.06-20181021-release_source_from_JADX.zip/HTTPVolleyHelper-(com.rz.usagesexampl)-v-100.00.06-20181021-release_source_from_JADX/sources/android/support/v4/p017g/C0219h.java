package android.support.v4.p017g;

/* renamed from: android.support.v4.g.h */
public interface C0219h {
    void stopNestedScroll();
}
