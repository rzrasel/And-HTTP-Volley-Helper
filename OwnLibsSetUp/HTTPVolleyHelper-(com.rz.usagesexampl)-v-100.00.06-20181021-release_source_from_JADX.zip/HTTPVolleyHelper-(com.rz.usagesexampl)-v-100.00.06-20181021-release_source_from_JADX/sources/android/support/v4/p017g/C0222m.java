package android.support.v4.p017g;

import android.view.View;
import android.view.ViewGroup;

/* renamed from: android.support.v4.g.m */
public class C0222m {
    /* renamed from: a */
    private final ViewGroup f775a;
    /* renamed from: b */
    private int f776b;

    public C0222m(ViewGroup viewGroup) {
        this.f775a = viewGroup;
    }

    /* renamed from: a */
    public int m832a() {
        return this.f776b;
    }

    /* renamed from: a */
    public void m833a(View view) {
        m834a(view, 0);
    }

    /* renamed from: a */
    public void m834a(View view, int i) {
        this.f776b = 0;
    }

    /* renamed from: a */
    public void m835a(View view, View view2, int i) {
        m836a(view, view2, i, 0);
    }

    /* renamed from: a */
    public void m836a(View view, View view2, int i, int i2) {
        this.f776b = i;
    }
}
