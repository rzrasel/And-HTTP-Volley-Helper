package android.support.v4.p017g;

import android.view.View;

/* renamed from: android.support.v4.g.t */
public interface C0235t {
    /* renamed from: a */
    void mo99a(View view);

    /* renamed from: b */
    void mo100b(View view);

    /* renamed from: c */
    void mo101c(View view);
}
