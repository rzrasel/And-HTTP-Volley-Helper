package android.support.v4.p017g;

import android.view.View;

/* renamed from: android.support.v4.g.n */
public interface C0223n {
    /* renamed from: a */
    C0237w mo136a(View view, C0237w c0237w);
}
