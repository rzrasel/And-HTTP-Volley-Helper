package android.support.v4.app;

import android.arch.lifecycle.C0029p;
import java.util.List;

/* renamed from: android.support.v4.app.n */
public class C0129n {
    /* renamed from: a */
    private final List<C0530g> f543a;
    /* renamed from: b */
    private final List<C0129n> f544b;
    /* renamed from: c */
    private final List<C0029p> f545c;

    C0129n(List<C0530g> list, List<C0129n> list2, List<C0029p> list3) {
        this.f543a = list;
        this.f544b = list2;
        this.f545c = list3;
    }

    /* renamed from: a */
    List<C0530g> m475a() {
        return this.f543a;
    }

    /* renamed from: b */
    List<C0129n> m476b() {
        return this.f544b;
    }

    /* renamed from: c */
    List<C0029p> m477c() {
        return this.f545c;
    }
}
