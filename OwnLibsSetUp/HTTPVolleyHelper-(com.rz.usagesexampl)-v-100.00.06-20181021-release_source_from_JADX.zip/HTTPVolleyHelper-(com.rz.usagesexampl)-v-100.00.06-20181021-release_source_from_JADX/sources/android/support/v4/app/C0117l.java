package android.support.v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

/* renamed from: android.support.v4.app.l */
public abstract class C0117l {

    /* renamed from: android.support.v4.app.l$a */
    public static abstract class C0115a {
        /* renamed from: a */
        public void m455a(C0117l c0117l, C0530g c0530g) {
        }

        /* renamed from: a */
        public void m456a(C0117l c0117l, C0530g c0530g, Context context) {
        }

        /* renamed from: a */
        public void m457a(C0117l c0117l, C0530g c0530g, Bundle bundle) {
        }

        /* renamed from: a */
        public void m458a(C0117l c0117l, C0530g c0530g, View view, Bundle bundle) {
        }

        /* renamed from: b */
        public void m459b(C0117l c0117l, C0530g c0530g) {
        }

        /* renamed from: b */
        public void m460b(C0117l c0117l, C0530g c0530g, Context context) {
        }

        /* renamed from: b */
        public void m461b(C0117l c0117l, C0530g c0530g, Bundle bundle) {
        }

        /* renamed from: c */
        public void m462c(C0117l c0117l, C0530g c0530g) {
        }

        /* renamed from: c */
        public void m463c(C0117l c0117l, C0530g c0530g, Bundle bundle) {
        }

        /* renamed from: d */
        public void m464d(C0117l c0117l, C0530g c0530g) {
        }

        /* renamed from: d */
        public void m465d(C0117l c0117l, C0530g c0530g, Bundle bundle) {
        }

        /* renamed from: e */
        public void m466e(C0117l c0117l, C0530g c0530g) {
        }

        /* renamed from: f */
        public void m467f(C0117l c0117l, C0530g c0530g) {
        }

        /* renamed from: g */
        public void m468g(C0117l c0117l, C0530g c0530g) {
        }
    }

    /* renamed from: android.support.v4.app.l$b */
    public interface C0116b {
        /* renamed from: a */
        void m469a();
    }

    /* renamed from: a */
    public abstract void mo46a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: a */
    public abstract boolean mo47a();

    /* renamed from: b */
    public abstract List<C0530g> mo48b();

    /* renamed from: c */
    public abstract boolean mo49c();
}
