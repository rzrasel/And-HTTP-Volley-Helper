package android.support.v4.app;

import android.support.v4.p008a.C0098b;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: android.support.v4.app.u */
public abstract class C0150u {

    /* renamed from: android.support.v4.app.u$a */
    public interface C0149a<D> {
        /* renamed from: a */
        void m544a(C0098b<D> c0098b);

        /* renamed from: a */
        void m545a(C0098b<D> c0098b, D d);
    }

    /* renamed from: a */
    public abstract void mo37a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);
}
