package android.support.v4.app;

import android.util.AndroidRuntimeException;

/* renamed from: android.support.v4.app.y */
final class C0154y extends AndroidRuntimeException {
    public C0154y(String str) {
        super(str);
    }
}
