package android.support.v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

/* renamed from: android.support.v4.app.i */
public abstract class C0113i {
    /* renamed from: a */
    public C0530g mo39a(Context context, String str, Bundle bundle) {
        return C0530g.m2106a(context, str, bundle);
    }

    /* renamed from: a */
    public abstract View mo40a(int i);

    /* renamed from: a */
    public abstract boolean mo41a();
}
