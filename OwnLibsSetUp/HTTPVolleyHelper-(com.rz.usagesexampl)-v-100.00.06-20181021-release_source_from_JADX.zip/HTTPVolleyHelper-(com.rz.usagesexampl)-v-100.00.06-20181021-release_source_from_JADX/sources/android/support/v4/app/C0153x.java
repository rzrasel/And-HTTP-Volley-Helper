package android.support.v4.app;

import android.view.View;
import java.util.List;
import java.util.Map;

/* renamed from: android.support.v4.app.x */
public abstract class C0153x {
    /* renamed from: a */
    private static int f629a = 1048576;

    /* renamed from: a */
    public void m555a(List<String> list, List<View> list2, List<View> list3) {
    }

    /* renamed from: a */
    public void m556a(List<String> list, Map<String, View> map) {
    }

    /* renamed from: b */
    public void m557b(List<String> list, List<View> list2, List<View> list3) {
    }
}
