package android.support.v4.p016f;

/* renamed from: android.support.v4.f.j */
public class C0196j {
    /* renamed from: a */
    public static <T> T m711a(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }
}
