package android.support.v4.widget;

import android.support.v4.p014d.C0169a;

/* renamed from: android.support.v4.widget.b */
public interface C0244b {
    /* renamed from: a */
    public static final boolean f830a = C0169a.m617a();
}
