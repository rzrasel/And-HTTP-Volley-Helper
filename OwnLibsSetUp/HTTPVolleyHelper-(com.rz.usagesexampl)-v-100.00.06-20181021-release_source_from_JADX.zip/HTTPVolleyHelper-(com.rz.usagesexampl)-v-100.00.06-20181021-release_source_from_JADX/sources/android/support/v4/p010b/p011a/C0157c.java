package android.support.v4.p010b.p011a;

import android.graphics.drawable.Drawable;

/* renamed from: android.support.v4.b.a.c */
public interface C0157c {
    /* renamed from: a */
    Drawable mo67a();

    /* renamed from: a */
    void mo68a(Drawable drawable);
}
