package android.support.v4.p014d;

import android.os.Build.VERSION;

/* renamed from: android.support.v4.d.a */
public class C0169a {
    @Deprecated
    /* renamed from: a */
    public static boolean m617a() {
        return VERSION.SDK_INT >= 27;
    }
}
