package android.support.v4.p012c.p013a;

import android.view.SubMenu;

/* renamed from: android.support.v4.c.a.c */
public interface C0545c extends C0167a, SubMenu {
}
