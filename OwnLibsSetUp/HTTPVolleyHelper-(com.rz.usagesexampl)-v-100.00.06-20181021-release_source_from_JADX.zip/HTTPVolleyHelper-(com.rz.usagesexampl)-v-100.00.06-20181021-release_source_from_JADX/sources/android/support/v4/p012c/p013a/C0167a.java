package android.support.v4.p012c.p013a;

import android.view.Menu;

/* renamed from: android.support.v4.c.a.a */
public interface C0167a extends Menu {
}
