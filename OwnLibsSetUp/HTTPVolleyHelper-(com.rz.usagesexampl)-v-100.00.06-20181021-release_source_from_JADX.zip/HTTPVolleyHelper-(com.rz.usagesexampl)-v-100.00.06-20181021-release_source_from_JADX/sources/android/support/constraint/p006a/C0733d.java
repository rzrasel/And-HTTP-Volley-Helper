package android.support.constraint.p006a;

/* renamed from: android.support.constraint.a.d */
public class C0733d extends C0518b {
    public C0733d(C0070c c0070c) {
        super(c0070c);
    }

    /* renamed from: d */
    public void mo28d(C0077h c0077h) {
        super.mo28d(c0077h);
        c0077h.f393i--;
    }
}
