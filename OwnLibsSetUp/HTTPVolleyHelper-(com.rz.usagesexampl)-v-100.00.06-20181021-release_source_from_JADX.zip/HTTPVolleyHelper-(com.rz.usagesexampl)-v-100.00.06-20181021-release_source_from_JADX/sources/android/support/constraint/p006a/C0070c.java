package android.support.constraint.p006a;

import android.support.constraint.p006a.C0075g.C0074a;
import android.support.constraint.p006a.C0075g.C0519b;

/* renamed from: android.support.constraint.a.c */
public class C0070c {
    /* renamed from: a */
    C0074a<C0518b> f323a = new C0519b(256);
    /* renamed from: b */
    C0074a<C0077h> f324b = new C0519b(256);
    /* renamed from: c */
    C0077h[] f325c = new C0077h[32];
}
