package android.support.constraint.p006a.p007a;

/* renamed from: android.support.constraint.a.a.n */
public class C0516n extends C0066o {
    /* renamed from: a */
    float f1809a = 0.0f;

    /* renamed from: a */
    public void m2028a(int i) {
        if (this.i == 0 || this.f1809a != ((float) i)) {
            this.f1809a = (float) i;
            if (this.i == 1) {
                m265e();
            }
            m266f();
        }
    }

    /* renamed from: b */
    public void mo21b() {
        super.mo21b();
        this.f1809a = 0.0f;
    }

    /* renamed from: c */
    public void m2030c() {
        this.i = 2;
    }
}
