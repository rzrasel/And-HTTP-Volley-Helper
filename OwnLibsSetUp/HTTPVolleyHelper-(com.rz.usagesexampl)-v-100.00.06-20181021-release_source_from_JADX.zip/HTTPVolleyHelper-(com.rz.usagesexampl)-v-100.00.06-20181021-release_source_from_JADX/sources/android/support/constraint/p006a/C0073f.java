package android.support.constraint.p006a;

import java.util.ArrayList;

/* renamed from: android.support.constraint.a.f */
public class C0073f {
    /* renamed from: A */
    public long f344A;
    /* renamed from: B */
    public long f345B;
    /* renamed from: C */
    public ArrayList<String> f346C;
    /* renamed from: D */
    public long f347D;
    /* renamed from: a */
    public long f348a;
    /* renamed from: b */
    public long f349b;
    /* renamed from: c */
    public long f350c;
    /* renamed from: d */
    public long f351d;
    /* renamed from: e */
    public long f352e;
    /* renamed from: f */
    public long f353f;
    /* renamed from: g */
    public long f354g;
    /* renamed from: h */
    public long f355h;
    /* renamed from: i */
    public long f356i;
    /* renamed from: j */
    public long f357j;
    /* renamed from: k */
    public long f358k;
    /* renamed from: l */
    public long f359l;
    /* renamed from: m */
    public long f360m;
    /* renamed from: n */
    public long f361n;
    /* renamed from: o */
    public long f362o;
    /* renamed from: p */
    public long f363p;
    /* renamed from: q */
    public long f364q;
    /* renamed from: r */
    public long f365r;
    /* renamed from: s */
    public long f366s;
    /* renamed from: t */
    public long f367t;
    /* renamed from: u */
    public long f368u;
    /* renamed from: v */
    public long f369v;
    /* renamed from: w */
    public long f370w;
    /* renamed from: x */
    public long f371x;
    /* renamed from: y */
    public long f372y;
    /* renamed from: z */
    public long f373z;

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\n*** Metrics ***\nmeasures: ");
        stringBuilder.append(this.f348a);
        stringBuilder.append("\nadditionalMeasures: ");
        stringBuilder.append(this.f349b);
        stringBuilder.append("\nresolutions passes: ");
        stringBuilder.append(this.f350c);
        stringBuilder.append("\ntable increases: ");
        stringBuilder.append(this.f351d);
        stringBuilder.append("\nmaxTableSize: ");
        stringBuilder.append(this.f363p);
        stringBuilder.append("\nmaxVariables: ");
        stringBuilder.append(this.f368u);
        stringBuilder.append("\nmaxRows: ");
        stringBuilder.append(this.f369v);
        stringBuilder.append("\n\nminimize: ");
        stringBuilder.append(this.f352e);
        stringBuilder.append("\nminimizeGoal: ");
        stringBuilder.append(this.f367t);
        stringBuilder.append("\nconstraints: ");
        stringBuilder.append(this.f353f);
        stringBuilder.append("\nsimpleconstraints: ");
        stringBuilder.append(this.f354g);
        stringBuilder.append("\noptimize: ");
        stringBuilder.append(this.f355h);
        stringBuilder.append("\niterations: ");
        stringBuilder.append(this.f356i);
        stringBuilder.append("\npivots: ");
        stringBuilder.append(this.f357j);
        stringBuilder.append("\nbfs: ");
        stringBuilder.append(this.f358k);
        stringBuilder.append("\nvariables: ");
        stringBuilder.append(this.f359l);
        stringBuilder.append("\nerrors: ");
        stringBuilder.append(this.f360m);
        stringBuilder.append("\nslackvariables: ");
        stringBuilder.append(this.f361n);
        stringBuilder.append("\nextravariables: ");
        stringBuilder.append(this.f362o);
        stringBuilder.append("\nfullySolved: ");
        stringBuilder.append(this.f364q);
        stringBuilder.append("\ngraphOptimizer: ");
        stringBuilder.append(this.f365r);
        stringBuilder.append("\nresolvedWidgets: ");
        stringBuilder.append(this.f366s);
        stringBuilder.append("\noldresolvedWidgets: ");
        stringBuilder.append(this.f344A);
        stringBuilder.append("\nnonresolvedWidgets: ");
        stringBuilder.append(this.f345B);
        stringBuilder.append("\ncenterConnectionResolved: ");
        stringBuilder.append(this.f370w);
        stringBuilder.append("\nmatchConnectionResolved: ");
        stringBuilder.append(this.f371x);
        stringBuilder.append("\nchainConnectionResolved: ");
        stringBuilder.append(this.f372y);
        stringBuilder.append("\nbarrierConnectionResolved: ");
        stringBuilder.append(this.f373z);
        stringBuilder.append("\nproblematicsLayouts: ");
        stringBuilder.append(this.f346C);
        stringBuilder.append("\n");
        return stringBuilder.toString();
    }
}
