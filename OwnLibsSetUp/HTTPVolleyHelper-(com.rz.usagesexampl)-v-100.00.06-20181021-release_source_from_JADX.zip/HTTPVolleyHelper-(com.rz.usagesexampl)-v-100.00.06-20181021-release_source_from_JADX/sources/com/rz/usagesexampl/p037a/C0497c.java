package com.rz.usagesexampl.p037a;

import com.p028b.p029a.p035c.C0475a;
import java.lang.reflect.Type;
import java.util.ArrayList;

/* renamed from: com.rz.usagesexampl.a.c */
class C0497c<T> {
    /* renamed from: a */
    protected static <T> ArrayList<T> m1934a(Class<T> cls) {
        return new ArrayList();
    }

    /* renamed from: b */
    protected static <T> Type m1935b(Class<T> cls) {
        return C0475a.m1819a(ArrayList.class, cls).m1823b();
    }
}
