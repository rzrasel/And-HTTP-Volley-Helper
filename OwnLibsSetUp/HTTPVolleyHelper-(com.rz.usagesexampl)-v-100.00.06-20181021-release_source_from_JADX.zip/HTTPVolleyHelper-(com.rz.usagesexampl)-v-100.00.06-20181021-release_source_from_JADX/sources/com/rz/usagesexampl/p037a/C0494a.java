package com.rz.usagesexampl.p037a;

/* renamed from: com.rz.usagesexampl.a.a */
public @interface C0494a {
    /* renamed from: a */
    String m1922a();
}
