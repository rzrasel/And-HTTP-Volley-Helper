package com.rz.usagesexampl;

/* renamed from: com.rz.usagesexampl.a */
public class C0501a {
    /* renamed from: a */
    public String f1760a = "Hi I am test var";
}
