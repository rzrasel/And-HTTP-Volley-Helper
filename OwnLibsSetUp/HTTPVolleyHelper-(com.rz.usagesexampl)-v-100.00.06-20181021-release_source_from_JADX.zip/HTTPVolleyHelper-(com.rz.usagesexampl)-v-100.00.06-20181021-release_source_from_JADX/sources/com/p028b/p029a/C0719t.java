package com.p028b.p029a;

/* renamed from: com.b.a.t */
public final class C0719t extends C0488p {
    public C0719t(String str) {
        super(str);
    }

    public C0719t(String str, Throwable th) {
        super(str, th);
    }

    public C0719t(Throwable th) {
        super(th);
    }
}
