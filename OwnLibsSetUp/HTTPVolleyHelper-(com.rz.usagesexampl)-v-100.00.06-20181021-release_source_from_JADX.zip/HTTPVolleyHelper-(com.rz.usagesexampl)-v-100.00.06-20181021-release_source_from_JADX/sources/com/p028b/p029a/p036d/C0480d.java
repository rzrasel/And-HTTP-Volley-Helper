package com.p028b.p029a.p036d;

import java.io.IOException;

/* renamed from: com.b.a.d.d */
public final class C0480d extends IOException {
    public C0480d(String str) {
        super(str);
    }
}
