package com.p028b.p029a;

import com.p028b.p029a.p031b.C0453a;
import java.lang.reflect.Field;

/* renamed from: com.b.a.c */
public final class C0476c {
    /* renamed from: a */
    private final Field f1659a;

    public C0476c(Field field) {
        C0453a.m1755a((Object) field);
        this.f1659a = field;
    }
}
