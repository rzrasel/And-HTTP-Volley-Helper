package com.p028b.p029a;

/* renamed from: com.b.a.p */
public class C0488p extends RuntimeException {
    public C0488p(String str) {
        super(str);
    }

    public C0488p(String str, Throwable th) {
        super(str, th);
    }

    public C0488p(Throwable th) {
        super(th);
    }
}
