package com.p028b.p029a.p031b;

/* renamed from: com.b.a.b.i */
public interface C0469i<T> {
    /* renamed from: a */
    T mo399a();
}
