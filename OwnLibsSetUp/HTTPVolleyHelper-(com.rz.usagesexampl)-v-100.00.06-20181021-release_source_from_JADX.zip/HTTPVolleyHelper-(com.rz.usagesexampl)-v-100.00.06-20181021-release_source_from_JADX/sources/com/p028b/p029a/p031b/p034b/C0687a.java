package com.p028b.p029a.p031b.p034b;

import java.lang.reflect.AccessibleObject;

/* renamed from: com.b.a.b.b.a */
final class C0687a extends C0457b {
    C0687a() {
    }

    /* renamed from: a */
    public void mo398a(AccessibleObject accessibleObject) {
        accessibleObject.setAccessible(true);
    }
}
