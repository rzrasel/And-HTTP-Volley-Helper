package com.p028b.p029a.p031b;

/* renamed from: com.b.a.b.a */
public final class C0453a {
    /* renamed from: a */
    public static <T> T m1755a(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }

    /* renamed from: a */
    public static void m1756a(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }
}
