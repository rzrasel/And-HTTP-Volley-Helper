package com.p028b.p029a.p031b.p034b;

import com.p028b.p029a.p031b.C0460e;
import java.lang.reflect.AccessibleObject;

/* renamed from: com.b.a.b.b.b */
public abstract class C0457b {
    /* renamed from: a */
    private static final C0457b f1624a = (C0460e.m1784a() < 9 ? new C0687a() : new C0688c());

    /* renamed from: a */
    public static C0457b m1757a() {
        return f1624a;
    }

    /* renamed from: a */
    public abstract void mo398a(AccessibleObject accessibleObject);
}
