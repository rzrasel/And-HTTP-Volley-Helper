package com.p028b.p029a.p031b;

import com.p028b.p029a.C0487l;
import com.p028b.p029a.p031b.p032a.C0452n;
import com.p028b.p029a.p036d.C0479c;

/* renamed from: com.b.a.b.l */
public final class C0472l {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static com.p028b.p029a.C0487l m1811a(com.p028b.p029a.p036d.C0477a r2) {
        /*
        r2.mo369f();	 Catch:{ EOFException -> 0x0024, d -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        r0 = 0;
        r1 = com.p028b.p029a.p031b.p032a.C0452n.f1589X;	 Catch:{ EOFException -> 0x000d, d -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        r2 = r1.mo361b(r2);	 Catch:{ EOFException -> 0x000d, d -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        r2 = (com.p028b.p029a.C0487l) r2;	 Catch:{ EOFException -> 0x000d, d -> 0x001d, IOException -> 0x0016, NumberFormatException -> 0x000f }
        return r2;
    L_0x000d:
        r2 = move-exception;
        goto L_0x0026;
    L_0x000f:
        r2 = move-exception;
        r0 = new com.b.a.t;
        r0.<init>(r2);
        throw r0;
    L_0x0016:
        r2 = move-exception;
        r0 = new com.b.a.m;
        r0.<init>(r2);
        throw r0;
    L_0x001d:
        r2 = move-exception;
        r0 = new com.b.a.t;
        r0.<init>(r2);
        throw r0;
    L_0x0024:
        r2 = move-exception;
        r0 = 1;
    L_0x0026:
        if (r0 == 0) goto L_0x002b;
    L_0x0028:
        r2 = com.p028b.p029a.C0716n.f2581a;
        return r2;
    L_0x002b:
        r0 = new com.b.a.t;
        r0.<init>(r2);
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.b.a.b.l.a(com.b.a.d.a):com.b.a.l");
    }

    /* renamed from: a */
    public static void m1812a(C0487l c0487l, C0479c c0479c) {
        C0452n.f1589X.mo360a(c0479c, c0487l);
    }
}
