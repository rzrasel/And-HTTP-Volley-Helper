package com.p028b.p029a.p031b;

import com.p028b.p029a.p036d.C0477a;

/* renamed from: com.b.a.b.f */
public abstract class C0461f {
    /* renamed from: a */
    public static C0461f f1629a;

    /* renamed from: a */
    public abstract void mo401a(C0477a c0477a);
}
