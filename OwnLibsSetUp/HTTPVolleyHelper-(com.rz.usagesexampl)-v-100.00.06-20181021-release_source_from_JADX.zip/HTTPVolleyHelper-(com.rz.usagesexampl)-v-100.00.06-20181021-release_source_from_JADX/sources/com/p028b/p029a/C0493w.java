package com.p028b.p029a;

import com.p028b.p029a.p035c.C0475a;

/* renamed from: com.b.a.w */
public interface C0493w {
    /* renamed from: a */
    <T> C0492v<T> mo362a(C0482f c0482f, C0475a<T> c0475a);
}
