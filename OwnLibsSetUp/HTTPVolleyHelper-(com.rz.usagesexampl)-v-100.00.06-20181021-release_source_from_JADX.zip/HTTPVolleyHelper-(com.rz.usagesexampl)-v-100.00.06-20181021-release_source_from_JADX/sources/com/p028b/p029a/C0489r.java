package com.p028b.p029a;

/* renamed from: com.b.a.r */
public interface C0489r {
}
