package com.p028b.p029a;

import java.lang.reflect.Type;

/* renamed from: com.b.a.k */
public interface C0486k<T> {
    /* renamed from: a */
    T m1901a(C0487l c0487l, Type type, C0485j c0485j);
}
