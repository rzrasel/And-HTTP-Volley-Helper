package com.p028b.p029a;

/* renamed from: com.b.a.b */
public interface C0474b {
    /* renamed from: a */
    boolean m1816a(C0476c c0476c);

    /* renamed from: a */
    boolean m1817a(Class<?> cls);
}
