package com.p028b.p029a;

import java.lang.reflect.Type;

/* renamed from: com.b.a.s */
public interface C0490s<T> {
    /* renamed from: a */
    C0487l m1916a(T t, Type type, C0489r c0489r);
}
