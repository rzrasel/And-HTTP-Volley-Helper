package com.p028b.p029a;

import java.lang.reflect.Type;

/* renamed from: com.b.a.h */
public interface C0484h<T> {
    /* renamed from: a */
    T m1900a(Type type);
}
