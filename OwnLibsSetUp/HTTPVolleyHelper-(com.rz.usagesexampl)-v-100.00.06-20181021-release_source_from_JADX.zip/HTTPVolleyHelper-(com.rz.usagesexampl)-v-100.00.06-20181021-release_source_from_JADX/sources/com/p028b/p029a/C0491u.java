package com.p028b.p029a;

/* renamed from: com.b.a.u */
public enum C0491u {
    DEFAULT {
    },
    STRING {
    }
}
