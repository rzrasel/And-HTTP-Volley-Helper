package com.p028b.p029a;

/* renamed from: com.b.a.n */
public final class C0716n extends C0487l {
    /* renamed from: a */
    public static final C0716n f2581a = new C0716n();

    public boolean equals(Object obj) {
        if (this != obj) {
            if (!(obj instanceof C0716n)) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        return C0716n.class.hashCode();
    }
}
