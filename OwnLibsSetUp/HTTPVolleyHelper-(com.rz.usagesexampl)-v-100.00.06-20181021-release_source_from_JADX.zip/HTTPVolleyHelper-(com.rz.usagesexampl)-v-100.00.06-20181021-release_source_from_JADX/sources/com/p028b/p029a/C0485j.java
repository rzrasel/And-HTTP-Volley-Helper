package com.p028b.p029a;

/* renamed from: com.b.a.j */
public interface C0485j {
}
