package com.p028b.p029a;

import java.lang.reflect.Field;

/* renamed from: com.b.a.e */
public interface C0481e {
    /* renamed from: a */
    String mo535a(Field field);
}
