package com.p028b.p029a;

/* renamed from: com.b.a.m */
public final class C0715m extends C0488p {
    public C0715m(String str) {
        super(str);
    }

    public C0715m(String str, Throwable th) {
        super(str, th);
    }

    public C0715m(Throwable th) {
        super(th);
    }
}
