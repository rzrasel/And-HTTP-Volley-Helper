package com.p025a.p026a;

/* renamed from: com.a.a.h */
public interface C0423h {
    /* renamed from: a */
    C0425k mo345a(C0429n<?> c0429n);
}
