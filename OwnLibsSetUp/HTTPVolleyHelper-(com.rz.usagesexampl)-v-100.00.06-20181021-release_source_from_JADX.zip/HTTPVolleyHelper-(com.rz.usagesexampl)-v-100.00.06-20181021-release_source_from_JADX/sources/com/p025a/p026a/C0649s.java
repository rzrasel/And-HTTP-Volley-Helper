package com.p025a.p026a;

/* renamed from: com.a.a.s */
public class C0649s extends C0437u {
    public C0649s(C0425k c0425k) {
        super(c0425k);
    }
}
