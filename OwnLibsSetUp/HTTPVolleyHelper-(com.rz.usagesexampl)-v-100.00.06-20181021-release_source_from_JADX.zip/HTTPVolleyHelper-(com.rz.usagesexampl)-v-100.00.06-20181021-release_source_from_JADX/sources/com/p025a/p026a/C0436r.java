package com.p025a.p026a;

/* renamed from: com.a.a.r */
public interface C0436r {
    /* renamed from: a */
    int mo354a();

    /* renamed from: a */
    void mo355a(C0437u c0437u);

    /* renamed from: b */
    int mo356b();
}
