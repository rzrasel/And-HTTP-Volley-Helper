package com.p025a.p026a;

/* renamed from: com.a.a.j */
public class C0647j extends C0437u {
    public C0647j(Throwable th) {
        super(th);
    }
}
