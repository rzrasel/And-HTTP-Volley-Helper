package com.p025a.p026a;

/* renamed from: com.a.a.u */
public class C0437u extends Exception {
    /* renamed from: a */
    public final C0425k f1549a;
    /* renamed from: b */
    private long f1550b;

    public C0437u() {
        this.f1549a = null;
    }

    public C0437u(C0425k c0425k) {
        this.f1549a = c0425k;
    }

    public C0437u(Throwable th) {
        super(th);
        this.f1549a = null;
    }

    /* renamed from: a */
    void m1726a(long j) {
        this.f1550b = j;
    }
}
