package com.p025a.p026a;

/* renamed from: com.a.a.l */
public class C0769l extends C0647j {
    public C0769l(Throwable th) {
        super(th);
    }
}
