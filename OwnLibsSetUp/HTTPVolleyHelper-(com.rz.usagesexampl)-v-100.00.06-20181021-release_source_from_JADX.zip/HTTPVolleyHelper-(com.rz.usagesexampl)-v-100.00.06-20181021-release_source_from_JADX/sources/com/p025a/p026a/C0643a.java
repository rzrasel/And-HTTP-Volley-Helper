package com.p025a.p026a;

import android.content.Intent;

/* renamed from: com.a.a.a */
public class C0643a extends C0437u {
    /* renamed from: b */
    private Intent f2439b;

    public C0643a(C0425k c0425k) {
        super(c0425k);
    }

    public String getMessage() {
        return this.f2439b != null ? "User needs to (re)enter credentials." : super.getMessage();
    }
}
