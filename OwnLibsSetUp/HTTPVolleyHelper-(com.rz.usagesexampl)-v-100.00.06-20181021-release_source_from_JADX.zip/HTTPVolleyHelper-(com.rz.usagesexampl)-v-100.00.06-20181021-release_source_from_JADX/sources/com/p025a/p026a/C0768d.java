package com.p025a.p026a;

/* renamed from: com.a.a.d */
public class C0768d extends C0649s {
    public C0768d(C0425k c0425k) {
        super(c0425k);
    }
}
