package com.p025a.p026a.p027a;

import com.p025a.p026a.C0429n;
import java.util.Map;

/* renamed from: com.a.a.a.a */
public abstract class C0639a implements C0412g {
    /* renamed from: a */
    public abstract C0411f mo534a(C0429n<?> c0429n, Map<String, String> map);
}
