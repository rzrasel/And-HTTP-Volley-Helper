package com.p025a.p026a.p027a;

@Deprecated
/* renamed from: com.a.a.a.g */
public interface C0412g {
}
