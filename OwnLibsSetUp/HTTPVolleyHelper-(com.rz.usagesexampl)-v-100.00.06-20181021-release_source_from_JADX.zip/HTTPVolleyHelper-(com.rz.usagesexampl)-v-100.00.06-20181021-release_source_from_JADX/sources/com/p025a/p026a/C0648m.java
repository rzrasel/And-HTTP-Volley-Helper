package com.p025a.p026a;

/* renamed from: com.a.a.m */
public class C0648m extends C0437u {
    public C0648m(Throwable th) {
        super(th);
    }
}
