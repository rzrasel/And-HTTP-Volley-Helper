package com.p025a.p026a;

/* renamed from: com.a.a.q */
public interface C0435q {
    /* renamed from: a */
    void mo357a(C0429n<?> c0429n, C0434p<?> c0434p);

    /* renamed from: a */
    void mo358a(C0429n<?> c0429n, C0434p<?> c0434p, Runnable runnable);

    /* renamed from: a */
    void mo359a(C0429n<?> c0429n, C0437u c0437u);
}
